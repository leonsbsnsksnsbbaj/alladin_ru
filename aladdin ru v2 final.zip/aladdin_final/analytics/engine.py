# analytics/engine.py
"""
Аналитический движок.
Считает RSI, MACD, моментум, объёмный спайк, итоговый скор.
"""

import logging
import numpy as np
from typing import List, Dict

log = logging.getLogger("aladdin.analytics")


class AnalyticsEngine:
    def __init__(self, cfg):
        self.cfg = cfg

    def score(self, instrument: dict, news_scores: Dict[str, float] = None) -> dict:
        """
        Считает итоговый скор инструмента от 0 до 1.
        Чем выше — тем лучше сигнал к покупке.
        """
        candles = instrument.get("candles", [])
        if len(candles) < 20:
            return {"score": 0.0, "rsi": 50.0, "momentum_3m": 0.0, "volume_spike": 1.0}

        closes  = np.array([c["close"]  for c in candles], dtype=float)
        volumes = np.array([c["volume"] for c in candles], dtype=float)

        rsi        = self._rsi(closes)
        macd_sig   = self._macd_signal(closes)
        momentum   = self._momentum(closes, 63)   # ~3 месяца
        mom_1m     = self._momentum(closes, 21)
        vol_spike  = self._volume_spike(volumes)
        trend      = self._trend_strength(closes)

        # Новостной сентимент
        ticker     = instrument.get("ticker", "")
        news_s     = (news_scores or {}).get(ticker, 0.5)

        # ── Взвешенный скор ────────────────────────────
        # RSI: лучше когда 30-55 (не перекуплен, с потенциалом роста)
        rsi_score = 1.0 - abs(rsi - 42.5) / 42.5
        rsi_score = max(0.0, min(1.0, rsi_score))

        # Моментум: нормализуем в 0-1
        mom_score  = max(0.0, min(1.0, 0.5 + momentum / 60))
        mom1_score = max(0.0, min(1.0, 0.5 + mom_1m / 30))

        # Объём: спайк ≥ 2.5x = сильный сигнал
        vol_score  = min(1.0, vol_spike / 4.0)

        # Тренд
        trend_score = max(0.0, min(1.0, trend))

        composite = (
            rsi_score    * 0.20 +
            macd_sig     * 0.20 +
            mom_score    * 0.18 +
            mom1_score   * 0.12 +
            vol_score    * 0.15 +
            trend_score  * 0.05 +
            news_s       * 0.10
        )

        return {
            "score":         round(float(composite), 3),
            "rsi":           round(float(rsi), 1),
            "macd_signal":   round(float(macd_sig), 3),
            "momentum_3m":   round(float(momentum), 1),
            "momentum_1m":   round(float(mom_1m), 1),
            "volume_spike":  round(float(vol_spike), 2),
            "trend":         round(float(trend_score), 3),
            "news_score":    round(float(news_s), 3),
        }

    # ──────────────────────────────────────────────────────
    def _rsi(self, closes: np.ndarray, period: int = 14) -> float:
        if len(closes) < period + 1:
            return 50.0
        deltas = np.diff(closes[-(period+1):])
        gains  = np.where(deltas > 0, deltas, 0.0)
        losses = np.where(deltas < 0, -deltas, 0.0)
        avg_g  = gains.mean()
        avg_l  = losses.mean()
        if avg_l < 1e-9:
            return 100.0
        rs = avg_g / avg_l
        return float(100 - 100 / (1 + rs))

    def _macd_signal(self, closes: np.ndarray,
                     fast: int = 12, slow: int = 26, signal: int = 9) -> float:
        if len(closes) < slow + signal:
            return 0.5
        ema_fast  = self._ema(closes, fast)
        ema_slow  = self._ema(closes, slow)
        macd_line = ema_fast - ema_slow
        # Нормализуем знак в 0-1
        return float(max(0.0, min(1.0, 0.5 + np.sign(macd_line[-1]) * 0.25)))

    def _ema(self, arr: np.ndarray, period: int) -> np.ndarray:
        k = 2 / (period + 1)
        ema = np.zeros_like(arr)
        ema[0] = arr[0]
        for i in range(1, len(arr)):
            ema[i] = arr[i] * k + ema[i-1] * (1 - k)
        return ema

    def _momentum(self, closes: np.ndarray, period: int) -> float:
        if len(closes) < period + 1:
            return 0.0
        return float((closes[-1] / closes[-period-1] - 1) * 100)

    def _volume_spike(self, volumes: np.ndarray, period: int = 20) -> float:
        if len(volumes) < period + 1:
            return 1.0
        avg = volumes[-period-1:-1].mean()
        if avg < 1:
            return 1.0
        return float(volumes[-1] / avg)

    def _trend_strength(self, closes: np.ndarray, period: int = 20) -> float:
        if len(closes) < period:
            return 0.5
        x = np.arange(period)
        y = closes[-period:]
        slope = float(np.polyfit(x, y, 1)[0])
        # Нормализуем
        pct_slope = slope / (y.mean() + 1e-9) * period
        return max(0.0, min(1.0, 0.5 + pct_slope * 5))

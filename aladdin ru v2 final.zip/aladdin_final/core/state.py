# core/state.py
"""
Состояние бота в памяти. Один экземпляр на весь процесс.
"""

from dataclasses import dataclass, field
from typing import List, Set, Dict


@dataclass
class BotState:
    is_running:          bool  = True    # False = пауза торговли
    cycle_count:         int   = 0       # счётчик циклов сканирования
    universe:            List  = field(default_factory=list)   # все инструменты
    signals:             List  = field(default_factory=list)   # топ сигналы
    portfolio:           List  = field(default_factory=list)   # текущий портфель
    news_scores:         Dict  = field(default_factory=dict)   # {ticker: score}
    peak_value:          float = 0.0     # максимум портфеля (для просадки)
    start_value:         float = 0.0     # стоимость при старте
    day_start_value:     float = 0.0     # стоимость на начало дня
    last_rebalance_day:  str   = ""      # дата последней ребалансировки
    last_report_date:    str   = ""      # дата последнего дневного отчёта
    notified_signals:    Set   = field(default_factory=set)    # уже уведомленные
    account_id:          str   = ""      # ID счёта в Т-Банк

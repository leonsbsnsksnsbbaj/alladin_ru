# core/config.py
"""
Все настройки ALADDIN RU v2.
Значения берутся из .env файла.
"""

import os
import logging
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger("aladdin.config")


@dataclass
class Config:
    # ── Брокер ──────────────────────────────────────────
    TINKOFF_TOKEN:      str   = ""
    TINKOFF_ACCOUNT_ID: str   = ""
    SANDBOX:            bool  = True      # True = песочница, False = реальные деньги

    # ── Telegram ────────────────────────────────────────
    TELEGRAM_BOT_TOKEN: str   = ""
    TELEGRAM_CHAT_ID:   str   = ""

    # ── YandexGPT (новости) ─────────────────────────────
    YAGPT_TOKEN:        str   = ""
    YAGPT_FOLDER_ID:    str   = ""

    # ── Расписание (секунды) ─────────────────────────────
    STOP_CHECK_INTERVAL:    int = 60       # проверка стопов каждую минуту
    NEWS_INTERVAL:          int = 180      # новости каждые 3 мин
    SCAN_INTERVAL:          int = 300      # скан каждые 5 мин
    REBALANCE_INTERVAL:     int = 86400    # ребаланс раз в сутки

    # ── Торговое время (МСК) ─────────────────────────────
    TRADING_START:          str = "10:00"
    TRADING_END:            str = "18:30"
    REBALANCE_TIME:         str = "10:15"
    MORNING_REPORT_TIME:    str = "09:45"
    DAILY_REPORT_TIME:      str = "19:00"

    # ── Риск-менеджмент ──────────────────────────────────
    STOP_LOSS_PCT:          float = 0.08   # -8% по позиции → продаём
    TAKE_PROFIT_PCT:        float = 0.25   # +25% по позиции → фиксируем
    MAX_DRAWDOWN:           float = 0.15   # -15% портфеля → стоп системы
    MAX_DAILY_LOSS:         float = 0.05   # -5% за день → пауза торговли

    # ── Портфель ─────────────────────────────────────────
    MAX_POSITIONS:          int   = 15     # максимум открытых позиций
    MAX_POSITION_PCT:       float = 0.10   # не более 10% в одну позицию
    MIN_POSITION_PCT:       float = 0.02   # не менее 2% на позицию
    STOCKS_ALLOCATION:      float = 0.60   # 60% в акции
    BONDS_ALLOCATION:       float = 0.25   # 25% в облигации
    CASH_RESERVE:           float = 0.05   # 5% кэш-резерв
    # остаток (10%) = золото, фьючерсы, ЦФА

    # ── Сигналы ──────────────────────────────────────────
    SIGNAL_THRESHOLD:       float = 0.72   # минимальный скор для покупки
    SELL_THRESHOLD:         float = 0.38   # скор ниже этого → продаём
    VOLUME_SPIKE_THRESHOLD: float = 2.5    # объём в X раз выше среднего → аномалия
    CORRELATION_LIMIT:      float = 0.75   # не берём если корреляция > 75%

    # ── Прочее ───────────────────────────────────────────
    MIN_ORDER_RUB:          float = 1000.0 # минимальная сумма ордера

    @classmethod
    def load(cls) -> "Config":
        """Загружает конфиг из .env файла и переменных окружения."""
        env_file = Path(".env")
        if env_file.exists():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, val = line.partition("=")
                    os.environ.setdefault(key.strip(), val.strip())

        cfg = cls(
            TINKOFF_TOKEN      = os.getenv("TINKOFF_TOKEN", ""),
            TINKOFF_ACCOUNT_ID = os.getenv("TINKOFF_ACCOUNT_ID", ""),
            SANDBOX            = os.getenv("SANDBOX", "true").lower() == "true",
            TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", ""),
            TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID", ""),
            YAGPT_TOKEN        = os.getenv("YAGPT_TOKEN", ""),
            YAGPT_FOLDER_ID    = os.getenv("YAGPT_FOLDER_ID", ""),
        )

        # Проверка обязательных полей
        missing = []
        if not cfg.TINKOFF_TOKEN:      missing.append("TINKOFF_TOKEN")
        if not cfg.TELEGRAM_BOT_TOKEN: missing.append("TELEGRAM_BOT_TOKEN")
        if not cfg.TELEGRAM_CHAT_ID:   missing.append("TELEGRAM_CHAT_ID")
        if missing:
            log.error(f"❌ Не заполнены обязательные поля в .env: {', '.join(missing)}")
            raise ValueError(f"Заполни .env: {missing}")

        if not cfg.YAGPT_TOKEN:
            log.warning("⚠️ YAGPT_TOKEN не задан — новости через ключевые слова (без GPT)")

        log.info(f"Config загружен. Sandbox={cfg.SANDBOX}")
        return cfg

# core/scheduler.py
"""
Главный планировщик. Запускает все задачи по расписанию.

Каждую минуту   → _check_stops()
Каждые 3 мин    → _fetch_news()
Каждые 5 мин    → _run_scan()
Раз в день 10:15 → _run_rebalance()
09:45            → _morning_brief()
19:00            → _daily_report()
"""

import asyncio
import logging
from datetime import datetime, timedelta

log = logging.getLogger("aladdin.scheduler")


class Scheduler:
    def __init__(self, cfg, state, broker, analytics,
                 optimizer, risk, tg, news, cashflow):
        self.cfg       = cfg
        self.state     = state
        self.broker    = broker
        self.analytics = analytics
        self.optimizer = optimizer
        self.risk      = risk
        self.tg        = tg
        self.news      = news
        self.cashflow  = cashflow

        self._last_stop_check  = datetime.min
        self._last_news        = datetime.min
        self._last_scan        = datetime.min
        self._last_morning     = ""
        self._last_report      = ""

    # ══════════════════════════════════════════════════════
    #  ГЛАВНЫЙ ЦИКЛ
    # ══════════════════════════════════════════════════════
    async def run_forever(self):
        log.info("Планировщик запущен")
        while True:
            try:
                now = datetime.now()
                await self._tick(now)
                await asyncio.sleep(10)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.exception(f"Ошибка в планировщике: {e}")
                await asyncio.sleep(30)

    async def _tick(self, now: datetime):
        if not self.state.is_running:
            return

        # Не торгуем вне торговых часов
        trading = self._is_trading_time(now)
        self.state.cycle_count += 1

        # Каждую минуту — стоп-лоссы
        if (now - self._last_stop_check).seconds >= self.cfg.STOP_CHECK_INTERVAL:
            self._last_stop_check = now
            if trading:
                await self._check_stops()

        # Каждые 3 мин — новости
        if (now - self._last_news).seconds >= self.cfg.NEWS_INTERVAL:
            self._last_news = now
            await self._fetch_news()

        # Каждые 5 мин — сканирование
        if (now - self._last_scan).seconds >= self.cfg.SCAN_INTERVAL:
            self._last_scan = now
            if trading:
                await self._run_scan()

        # Утренний брифинг
        if trading and now.strftime("%H:%M") == self.cfg.MORNING_REPORT_TIME:
            today = now.strftime("%Y-%m-%d")
            if self._last_morning != today:
                self._last_morning = today
                await self._morning_brief()

        # Ребаланс
        if trading and now.strftime("%H:%M") == self.cfg.REBALANCE_TIME:
            today = now.strftime("%Y-%m-%d")
            if self.state.last_rebalance_day != today:
                self.state.last_rebalance_day = today
                await self._run_rebalance()

        # Дневной отчёт
        if now.strftime("%H:%M") == self.cfg.DAILY_REPORT_TIME:
            today = now.strftime("%Y-%m-%d")
            if self._last_report != today:
                self._last_report = today
                await self._daily_report()

        # Автовывод по расписанию
        await self.cashflow.check_scheduled_withdrawals()

    # ══════════════════════════════════════════════════════
    #  СТОП-ЛОССЫ / ТЕЙК-ПРОФИТЫ (каждую минуту)
    # ══════════════════════════════════════════════════════
    async def _check_stops(self):
        try:
            portfolio = await self.broker.get_portfolio()
            positions = portfolio.get("positions", [])
            total     = portfolio.get("total_amount", 0)

            # Обновляем пик
            if total > self.state.peak_value:
                self.state.peak_value = total

            # Проверка общей просадки
            if self.state.peak_value > 0:
                dd = (self.state.peak_value - total) / self.state.peak_value
                if dd >= self.cfg.MAX_DRAWDOWN:
                    log.warning(f"⛔ Макс. просадка {dd:.1%} — пауза торговли!")
                    self.state.is_running = False
                    await self.tg.send_text(
                        f"⛔ <b>СИСТЕМА НА ПАУЗЕ</b>\n"
                        f"Просадка портфеля: -{dd:.1%}\n"
                        f"Лимит: -{self.cfg.MAX_DRAWDOWN:.0%}\n"
                        f"Возобнови вручную: /resume"
                    )
                    return

            # Стоп-лосс и тейк-профит по каждой позиции
            for pos in positions:
                entry = pos.get("avg_price", 0)
                price = pos.get("current_price", 0)
                if entry <= 0 or price <= 0:
                    continue
                pnl_pct = (price - entry) / entry

                if pnl_pct <= -self.cfg.STOP_LOSS_PCT:
                    await self._close_position(pos, reason="stop_loss", pnl=pnl_pct)
                elif pnl_pct >= self.cfg.TAKE_PROFIT_PCT:
                    await self._close_position(pos, reason="take_profit", pnl=pnl_pct)

        except Exception as e:
            log.debug(f"_check_stops: {e}")

    async def _close_position(self, pos: dict, reason: str, pnl: float):
        ticker = pos.get("ticker", pos.get("figi", "?")[:6])
        lots   = pos.get("quantity_lots", 1)
        price  = pos.get("current_price", 0)

        result = await self.broker.sell(figi=pos["figi"], lots=lots, comment=reason)
        if not result:
            return

        if reason == "stop_loss":
            await self.tg.send_text(
                f"🛑 <b>СТОП-ЛОСС: {ticker}</b>\n"
                f"Убыток: <code>{pnl:+.1%}</code>\n"
                f"Продано {lots} лот(ов) по {price:.2f} ₽\n"
                f"Позиция закрыта автоматически"
            )
        else:
            await self.tg.send_text(
                f"🏆 <b>ТЕЙК-ПРОФИТ: {ticker}</b>\n"
                f"Прибыль: <code>{pnl:+.1%}</code>\n"
                f"Продано {lots} лот(ов) по {price:.2f} ₽"
            )
        log.info(f"{reason}: {ticker} {pnl:+.1%}")

    # ══════════════════════════════════════════════════════
    #  НОВОСТИ (каждые 3 мин)
    # ══════════════════════════════════════════════════════
    async def _fetch_news(self):
        try:
            scores = await self.news.fetch_and_analyze(self.state.universe)
            self.state.news_scores = scores
        except Exception as e:
            log.debug(f"_fetch_news: {e}")

    # ══════════════════════════════════════════════════════
    #  СКАНИРОВАНИЕ РЫНКА (каждые 5 мин)
    # ══════════════════════════════════════════════════════
    async def _run_scan(self):
        try:
            # Получаем вселенную инструментов
            universe = await self.broker.get_universe()
            if not universe:
                return
            self.state.universe = universe

            # Загружаем свечи батчами
            analyzed = []
            for i in range(0, min(len(universe), 60), 10):
                batch = universe[i:i+10]
                for instr in batch:
                    try:
                        candles = await self.broker.get_candles(instr["figi"], days=60)
                        if len(candles) < 20:
                            continue
                        instr["candles"] = candles
                        score_data = self.analytics.score(instr, self.state.news_scores)
                        analyzed.append({**instr, **score_data})
                    except Exception:
                        pass
                await asyncio.sleep(0.2)

            # Сортируем по скору
            analyzed.sort(key=lambda x: x.get("score", 0), reverse=True)
            self.state.signals = analyzed

            # Уведомляем о новых сильных сигналах
            for sig in analyzed[:5]:
                if sig["score"] >= self.cfg.SIGNAL_THRESHOLD:
                    key = f"{sig['ticker']}_{sig['score']:.2f}"
                    if key not in self.state.notified_signals:
                        self.state.notified_signals.add(key)
                        await self._notify_signal(sig)

            log.info(f"Скан: {len(analyzed)} инструментов, "
                     f"топ скор {analyzed[0]['score']:.2f} ({analyzed[0]['ticker']})"
                     if analyzed else "Скан: нет данных")

        except Exception as e:
            log.exception(f"_run_scan: {e}")

    async def _notify_signal(self, sig: dict):
        bar = "█" * round(sig["score"]*5) + "░"*(5 - round(sig["score"]*5))
        vol_txt = f"⚡ Объём {sig.get('volume_spike',1):.1f}x" if sig.get("volume_spike",1) >= 2.5 else ""
        await self.tg.send_text(
            f"🔍 <b>СИГНАЛ: {sig['ticker']}</b>  {bar}\n"
            f"Скор: <code>{sig['score']:.2f}</code>  "
            f"RSI: <code>{sig.get('rsi',50):.0f}</code>  "
            f"Моментум: <code>{sig.get('momentum_3m',0):+.1f}%</code>\n"
            f"{vol_txt}"
        )

    # ══════════════════════════════════════════════════════
    #  РЕБАЛАНСИРОВКА (раз в день в 10:15)
    # ══════════════════════════════════════════════════════
    async def _run_rebalance(self):
        try:
            log.info("Начало ребалансировки...")
            portfolio = await self.broker.get_portfolio()
            total     = portfolio.get("total_amount", 0)
            positions = portfolio.get("positions", [])

            if total <= 0:
                log.warning("Портфель пуст — пропускаем ребалансировку")
                return

            # Обновляем day_start
            self.state.day_start_value = total

            # Считаем целевой портфель
            target = await self.optimizer.optimize(
                signals=self.state.signals, total_capital=total
            )
            if not target:
                return

            sells, buys = [], []

            # Продаём: позиции которых нет в цели или скор упал
            target_figis = {p["figi"] for p in target}
            for pos in positions:
                score  = pos.get("score", 0.5)
                in_tgt = pos["figi"] in target_figis
                if not in_tgt or score < self.cfg.SELL_THRESHOLD:
                    r = await self.broker.sell(
                        figi=pos["figi"],
                        lots=pos.get("quantity_lots", 1),
                        comment="rebalance_sell"
                    )
                    if r:
                        sells.append(pos.get("ticker", "?"))
                    await asyncio.sleep(0.3)

            await asyncio.sleep(1)

            # Покупаем: новые позиции и недовес
            current_figis = {p["figi"] for p in positions}
            for tgt in target:
                if tgt["figi"] not in current_figis:
                    if tgt.get("target_lots", 0) >= 1:
                        r = await self.broker.buy(
                            figi=tgt["figi"],
                            lots=tgt["target_lots"],
                            comment="rebalance_buy"
                        )
                        if r:
                            buys.append(tgt.get("ticker", "?"))
                        await asyncio.sleep(0.3)

            await self.tg.send_text(
                f"⚖️ <b>Ребалансировка выполнена</b>\n"
                f"🔴 Продано: {', '.join(sells) or '—'}\n"
                f"🟢 Куплено: {', '.join(buys) or '—'}\n"
                f"💼 Капитал: <code>{total:,.0f} ₽</code>"
            )
        except Exception as e:
            log.exception(f"_run_rebalance: {e}")

    # ══════════════════════════════════════════════════════
    #  ОТЧЁТЫ
    # ══════════════════════════════════════════════════════
    async def _morning_brief(self):
        try:
            top = self.state.signals[:5]
            if not top:
                return
            lines = ["☀️ <b>Утренний брифинг</b>", "─" * 26]
            for i, s in enumerate(top, 1):
                bar = "█"*round(s["score"]*5) + "░"*(5-round(s["score"]*5))
                lines.append(f"{i}. <b>{s['ticker']}</b> {bar} <code>{s['score']:.2f}</code>")
            await self.tg.send_text("\n".join(lines))
        except Exception as e:
            log.debug(f"_morning_brief: {e}")

    async def _daily_report(self):
        try:
            portfolio = await self.broker.get_portfolio()
            total     = portfolio.get("total_amount", 0)
            pnl_day   = total - self.state.day_start_value if self.state.day_start_value > 0 else 0
            pnl_total = total - self.state.start_value if self.state.start_value > 0 else 0

            await self.tg.send_text(
                f"📊 <b>Дневной отчёт</b>  "
                f"<code>{datetime.now().strftime('%d.%m.%Y')}</code>\n"
                f"{'─' * 28}\n"
                f"💼 Капитал:   <code>{total:>12,.0f} ₽</code>\n"
                f"📈 За день:   <code>{pnl_day:>+12,.0f} ₽</code>  "
                f"(<code>{pnl_day/self.state.day_start_value*100:+.2f}%</code>)\n"
                f"🏦 Всего P&L: <code>{pnl_total:>+12,.0f} ₽</code>\n"
                f"{'─' * 28}\n"
                f"Позиций: {len(portfolio.get('positions',[]))}  "
                f"Сигналов: {len(self.state.signals)}"
            )
        except Exception as e:
            log.debug(f"_daily_report: {e}")

    # ══════════════════════════════════════════════════════
    #  УТИЛИТЫ
    # ══════════════════════════════════════════════════════
    def _is_trading_time(self, now: datetime) -> bool:
        if now.weekday() >= 5:
            return False
        start = datetime.strptime(self.cfg.TRADING_START, "%H:%M").replace(
            year=now.year, month=now.month, day=now.day)
        end   = datetime.strptime(self.cfg.TRADING_END, "%H:%M").replace(
            year=now.year, month=now.month, day=now.day)
        return start <= now <= end

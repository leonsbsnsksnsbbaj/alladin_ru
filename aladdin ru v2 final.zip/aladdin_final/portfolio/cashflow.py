# portfolio/cashflow.py
"""
Управление деньгами:
- Вывод по запросу или по расписанию
- Пополнение → бот сам решает что докупить
- История всех операций
"""

import asyncio
import logging
import json
from datetime import datetime, timedelta
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict
from pathlib import Path

log = logging.getLogger("aladdin.cashflow")


@dataclass
class CashflowRecord:
    id:          str
    type:        str          # "deposit" | "withdrawal" | "auto_invest"
    amount:      float        # сумма в рублях
    timestamp:   str
    status:      str          # "pending" | "done" | "cancelled"
    comment:     str = ""
    trades:      List[dict] = field(default_factory=list)  # что купили/продали


class CashflowManager:
    """
    Всё что связано с движением денег в/из портфеля.
    """

    def __init__(self, cfg, broker, optimizer, tg):
        self.cfg       = cfg
        self.broker    = broker
        self.optimizer = optimizer
        self.tg        = tg
        self._history: List[CashflowRecord] = []
        self._scheduled_withdrawals: List[dict] = []
        self._data_file = Path("cashflow_history.json")
        self._load()

    # ══════════════════════════════════════════════════════
    #  ВЫВОД ДЕНЕГ
    # ══════════════════════════════════════════════════════

    async def request_withdrawal(self, amount: float, comment: str = "") -> dict:
        """
        Вывести сумму из портфеля.
        Бот продаёт позиции пропорционально, освобождает кэш.
        Возвращает результат.
        """
        log.info(f"Запрос на вывод: {amount:,.0f} ₽  [{comment}]")

        # 1. Проверка — достаточно ли кэша
        portfolio = await self.broker.get_portfolio()
        total     = portfolio.get("total_amount", 0)
        cash      = portfolio.get("cash_rub", 0)

        if amount > total * 0.95:
            msg = (f"⛔ Нельзя вывести {amount:,.0f} ₽ — "
                   f"это больше 95% портфеля ({total:,.0f} ₽).\n"
                   f"Максимум: {total*0.95:,.0f} ₽")
            await self.tg.send_text(msg)
            return {"status": "rejected", "reason": msg}

        needed_from_positions = max(0, amount - cash)
        sells_done = []

        # 2. Если кэша не хватает — продаём позиции
        if needed_from_positions > 10_000:
            sells_done = await self._liquidate_partial(
                needed_rub=needed_from_positions,
                positions=portfolio.get("positions", [])
            )

        # 3. Записываем операцию
        rec = CashflowRecord(
            id=f"W{datetime.now().strftime('%Y%m%d%H%M%S')}",
            type="withdrawal",
            amount=amount,
            timestamp=datetime.now().isoformat(),
            status="done",
            comment=comment,
            trades=sells_done,
        )
        self._history.append(rec)
        self._save()

        # 4. Уведомление
        await self._notify_withdrawal(amount, cash, sells_done, portfolio)

        return {"status": "ok", "amount": amount, "sells": sells_done}

    async def schedule_monthly_withdrawal(self, amount: float, day: int = 25):
        """
        Настроить автоматический ежемесячный вывод.
        day = день месяца (1–28)
        """
        self._scheduled_withdrawals = [{
            "type": "monthly",
            "amount": amount,
            "day": day,
            "active": True,
        }]
        self._save()
        await self.tg.send_text(
            f"✅ Автовывод настроен:\n"
            f"💰 Сумма: {amount:,.0f} ₽\n"
            f"📅 Каждое {day}-е число месяца\n"
            f"Отменить: /cancel_auto_withdrawal"
        )

    async def cancel_auto_withdrawal(self):
        self._scheduled_withdrawals = []
        self._save()
        await self.tg.send_text("❌ Автовывод отменён.")

    async def check_scheduled_withdrawals(self):
        """Вызывается из scheduler каждый день."""
        today = datetime.now()
        for sw in self._scheduled_withdrawals:
            if not sw.get("active"):
                continue
            if sw["type"] == "monthly" and today.day == sw["day"]:
                # Проверяем — уже выводили сегодня?
                today_str = today.strftime("%Y-%m-%d")
                already = any(
                    r.type == "withdrawal" and
                    r.timestamp.startswith(today_str) and
                    r.comment == "auto_monthly"
                    for r in self._history
                )
                if not already:
                    log.info(f"Автовывод {sw['amount']:,.0f} ₽")
                    await self.request_withdrawal(sw["amount"], comment="auto_monthly")

    # ══════════════════════════════════════════════════════
    #  ПОПОЛНЕНИЕ СЧЁТА
    # ══════════════════════════════════════════════════════

    async def handle_deposit(self, amount: float, signals: List[dict]):
        """
        Обнаружено пополнение счёта.
        Бот сам решает: сразу купить или подождать лучшего момента.
        """
        log.info(f"Пополнение: {amount:,.0f} ₽")

        # --- Анализируем рыночный момент ---
        market_score = self._assess_market_moment(signals)
        portfolio    = await self.broker.get_portfolio()

        rec = CashflowRecord(
            id=f"D{datetime.now().strftime('%Y%m%d%H%M%S')}",
            type="deposit",
            amount=amount,
            timestamp=datetime.now().isoformat(),
            status="pending",
            comment="",
        )

        if market_score >= 0.65:
            # Хороший момент — покупаем сразу
            trades = await self._invest_deposit(amount, signals, portfolio)
            rec.status = "done"
            rec.trades = trades
            action_msg = "🟢 Момент хороший — куплено сразу"
        elif market_score >= 0.45:
            # Нейтрально — разбиваем на 3 части по 3 дня (DCA)
            await self._schedule_dca(amount, signals, parts=3, days=3)
            rec.status  = "dca_scheduled"
            rec.comment = "DCA 3x3дня"
            action_msg  = "🟡 Нейтральный рынок — разбиваю на 3 покупки за 3 дня (DCA)"
        else:
            # Плохой момент — ждём дипа
            rec.status  = "waiting_dip"
            rec.comment = "Ждём дип"
            action_msg  = "🔴 Рынок перегрет — жду коррекции. Деньги в кэше."

        self._history.append(rec)
        self._save()

        await self._notify_deposit(amount, market_score, action_msg, rec)
        return rec

    async def _invest_deposit(self, amount: float, signals: List[dict],
                               portfolio: dict) -> List[dict]:
        """Распределяем деньги по текущим весам портфеля."""
        if not signals:
            return []

        total_after = portfolio.get("total_amount", 0) + amount
        target      = await self.optimizer.optimize(
            signals=signals[:10], total_capital=total_after
        )

        trades = []
        remaining = amount

        for pos in target[:8]:  # топ-8 позиций
            if remaining < 5_000:
                break
            # Сколько уже есть этой позиции
            current_val = next(
                (p["value_rub"] for p in portfolio.get("positions",[])
                 if p["figi"] == pos["figi"]), 0
            )
            target_val  = pos["target_rub"]
            buy_rub     = min(target_val - current_val, remaining * pos["weight"])

            if buy_rub < 1_000:
                continue

            price = pos.get("price", 1)
            lot   = pos.get("lot", 1)
            lots  = max(1, int(buy_rub / (price * lot)))

            result = await self.broker.buy(
                figi=pos["figi"], lots=lots,
                comment=f"DEPOSIT_INVEST"
            )
            if result:
                trade = {
                    "ticker": pos["ticker"],
                    "lots": lots,
                    "price": price,
                    "rub": lots * price * lot,
                    "score": pos.get("score", 0),
                }
                trades.append(trade)
                remaining -= trade["rub"]
                await asyncio.sleep(0.3)

        return trades

    async def _schedule_dca(self, amount: float, signals: List[dict],
                             parts: int, days: int):
        """DCA — покупаем частями через равные промежутки."""
        part_amount = amount / parts
        for i in range(parts):
            await asyncio.sleep(days * 86400 / parts * i)  # сдвиг
            portfolio = await self.broker.get_portfolio()
            await self._invest_deposit(part_amount, signals, portfolio)
            await self.tg.send_text(
                f"💰 DCA покупка {i+1}/{parts}: {part_amount:,.0f} ₽ инвестировано"
            )

    def _assess_market_moment(self, signals: List[dict]) -> float:
        """
        Оценивает текущий момент для покупки.
        0 = очень плохо (перегрет/падает)
        1 = отлично (дип/разворот)
        """
        if not signals:
            return 0.5
        avg_score = sum(s.get("score", 0.5) for s in signals[:10]) / min(10, len(signals))
        avg_mom   = sum(s.get("momentum_3m", 0) for s in signals[:10]) / max(1, len(signals[:10]))
        avg_rsi   = sum(s.get("rsi", 50) for s in signals[:10]) / max(1, len(signals[:10]))

        # Лучший момент: RSI низкий (перепроданность), скоры высокие
        rsi_score = max(0, (60 - avg_rsi) / 30)  # RSI < 30 = 1.0
        mom_score = 0.5 + min(0.5, avg_mom / 20)  # позитивный моментум
        return float(min(1.0, avg_score * 0.5 + rsi_score * 0.3 + mom_score * 0.2))

    # ══════════════════════════════════════════════════════
    #  ЧАСТИЧНАЯ ЛИКВИДАЦИЯ (для вывода)
    # ══════════════════════════════════════════════════════

    async def _liquidate_partial(self, needed_rub: float,
                                  positions: List[dict]) -> List[dict]:
        """
        Продаём позиции пропорционально чтобы освободить нужную сумму.
        Сначала продаём слабые позиции (низкий скор).
        """
        if not positions:
            return []

        total_val = sum(p.get("value_rub", 0) for p in positions)
        sells = []
        freed = 0.0

        # Сортируем — сначала продаём те что с наименьшим скором
        sorted_pos = sorted(positions,
                            key=lambda p: p.get("score", 0.5))

        for pos in sorted_pos:
            if freed >= needed_rub:
                break
            pos_val = pos.get("value_rub", 0)
            # Продаём долю от позиции
            sell_ratio = min(1.0, (needed_rub - freed) / pos_val)
            price = pos.get("current_price", 1)
            lot   = 1  # упрощённо
            qty   = pos.get("quantity", 0)
            sell_lots = max(1, int(qty * sell_ratio))

            result = await self.broker.sell(
                figi=pos["figi"],
                lots=sell_lots,
                comment="WITHDRAWAL_LIQUIDATION"
            )
            if result:
                sell_rub = sell_lots * price * lot
                freed   += sell_rub
                sells.append({
                    "ticker": pos.get("ticker", pos["figi"][:6]),
                    "lots": sell_lots,
                    "price": price,
                    "rub": sell_rub,
                })
                await asyncio.sleep(0.3)

        log.info(f"Ликвидация: освобождено {freed:,.0f} ₽, нужно {needed_rub:,.0f} ₽")
        return sells

    # ══════════════════════════════════════════════════════
    #  УВЕДОМЛЕНИЯ
    # ══════════════════════════════════════════════════════

    async def _notify_withdrawal(self, amount, cash, sells, portfolio):
        total = portfolio.get("total_amount", 0)
        text  = (
            f"💸 <b>ВЫВОД ВЫПОЛНЕН</b>\n"
            f"{'─'*28}\n"
            f"💰 Сумма: <code>{amount:,.0f} ₽</code>\n"
            f"🏦 Из кэша: <code>{min(amount,cash):,.0f} ₽</code>\n"
        )
        if sells:
            text += f"📦 Продано позиций: {len(sells)}\n"
            for s in sells[:4]:
                text += f"  🔴 {s['ticker']} {s['lots']}л → {s['rub']:,.0f} ₽\n"
        text += (
            f"{'─'*28}\n"
            f"💼 Остаток: <code>{total-amount:,.0f} ₽</code>\n"
            f"⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        )
        await self.tg._send(text)

    async def _notify_deposit(self, amount, market_score, action_msg, rec):
        score_bar = "█" * round(market_score*5) + "░"*(5-round(market_score*5))
        text = (
            f"📥 <b>ПОПОЛНЕНИЕ ОБНАРУЖЕНО</b>\n"
            f"{'─'*28}\n"
            f"💰 Сумма: <code>{amount:,.0f} ₽</code>\n"
            f"📊 Момент рынка: {score_bar} <code>{market_score:.2f}</code>\n"
            f"{'─'*28}\n"
            f"{action_msg}\n"
        )
        if rec.trades:
            text += f"\n<b>Куплено:</b>\n"
            for t in rec.trades[:5]:
                bar = "█"*round(t.get("score",0)*5)+"░"*(5-round(t.get("score",0)*5))
                text += f"  🟢 {t['ticker']} {t['lots']}л  {bar}  {t['rub']:,.0f}₽\n"
        text += f"\n⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        await self.tg._send(text)

    # ══════════════════════════════════════════════════════
    #  ИСТОРИЯ И СТАТИСТИКА
    # ══════════════════════════════════════════════════════

    def get_history(self, last_n: int = 20) -> List[CashflowRecord]:
        return self._history[-last_n:]

    def get_stats(self) -> dict:
        deposits    = [r for r in self._history if r.type == "deposit"]
        withdrawals = [r for r in self._history if r.type == "withdrawal"]
        return {
            "total_deposited":   sum(r.amount for r in deposits),
            "total_withdrawn":   sum(r.amount for r in withdrawals),
            "n_deposits":        len(deposits),
            "n_withdrawals":     len(withdrawals),
            "auto_withdrawal":   bool(self._scheduled_withdrawals),
            "auto_amount":       self._scheduled_withdrawals[0]["amount"]
                                 if self._scheduled_withdrawals else 0,
            "auto_day":          self._scheduled_withdrawals[0]["day"]
                                 if self._scheduled_withdrawals else None,
        }

    def _save(self):
        try:
            data = {
                "history": [asdict(r) for r in self._history],
                "scheduled": self._scheduled_withdrawals,
            }
            self._data_file.write_text(json.dumps(data, ensure_ascii=False, indent=2))
        except Exception as e:
            log.error(f"Ошибка сохранения cashflow: {e}")

    def _load(self):
        try:
            if self._data_file.exists():
                data = json.loads(self._data_file.read_text())
                self._history = [CashflowRecord(**r) for r in data.get("history", [])]
                self._scheduled_withdrawals = data.get("scheduled", [])
                log.info(f"Загружено {len(self._history)} операций cashflow")
        except Exception as e:
            log.error(f"Ошибка загрузки cashflow: {e}")

# portfolio/optimizer.py
"""
Оптимизатор портфеля.
Markowitz + факторные веса + корреляционный фильтр.
"""

import logging
import numpy as np
from typing import List

log = logging.getLogger("aladdin.optimizer")


class PortfolioOptimizer:
    def __init__(self, cfg):
        self.cfg = cfg

    async def optimize(self, signals: List[dict], total_capital: float) -> List[dict]:
        cfg = self.cfg
        if not signals or total_capital <= 0:
            return []

        stocks = [s for s in signals if s.get("type") == "stock"][:cfg.MAX_POSITIONS]
        bonds  = [s for s in signals if s.get("type") == "bond"][:5]

        # Убираем коррелированные
        stocks = self._diversify(stocks)

        stock_alloc = cfg.STOCKS_ALLOCATION
        bond_alloc  = cfg.BONDS_ALLOCATION if bonds else 0.0
        stock_alloc += cfg.BONDS_ALLOCATION - bond_alloc

        result = []
        result += self._weight_group(stocks, stock_alloc, total_capital)
        result += self._weight_group(bonds,  bond_alloc,  total_capital)
        return result

    def _diversify(self, instruments: List[dict]) -> List[dict]:
        """Убирает сильно коррелированные инструменты."""
        selected = []
        for instr in instruments:
            too_corr = False
            closes_a = np.array([c["close"] for c in instr.get("candles", [])])
            for chosen in selected:
                closes_b = np.array([c["close"] for c in chosen.get("candles", [])])
                n = min(len(closes_a), len(closes_b), 60)
                if n > 10:
                    r_a = np.diff(closes_a[-n:]) / (closes_a[-n:-1] + 1e-9)
                    r_b = np.diff(closes_b[-n:]) / (closes_b[-n:-1] + 1e-9)
                    m = min(len(r_a), len(r_b))
                    corr = float(np.corrcoef(r_a[-m:], r_b[-m:])[0, 1])
                    if abs(corr) > self.cfg.CORRELATION_LIMIT:
                        too_corr = True
                        break
            if not too_corr:
                selected.append(instr)
            if len(selected) >= self.cfg.MAX_POSITIONS:
                break
        return selected

    def _weight_group(self, instruments: List[dict],
                      allocation: float, total: float) -> List[dict]:
        if not instruments or allocation <= 0:
            return []
        score_sum = sum(max(0, i["score"]) for i in instruments)
        result = []
        for instr in instruments:
            w = (instr["score"] / score_sum * allocation
                 if score_sum > 0 else allocation / len(instruments))
            w = max(self.cfg.MIN_POSITION_PCT, min(self.cfg.MAX_POSITION_PCT, w))

            candles = instr.get("candles", [])
            price   = candles[-1]["close"] if candles else 1.0
            lot     = instr.get("lot", 1)
            target_rub  = total * w
            target_lots = max(1, int(target_rub / (price * lot)))

            result.append({
                **instr,
                "weight":       round(w, 4),
                "target_rub":   round(target_rub, 2),
                "target_lots":  target_lots,
                "price":        price,
            })
        return result

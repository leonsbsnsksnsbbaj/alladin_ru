# portfolio/risk.py
"""
Риск-менеджмент: просадка, VaR, концентрация.
"""

import logging
import numpy as np
from typing import List

log = logging.getLogger("aladdin.risk")


class RiskManager:
    def __init__(self, cfg):
        self.cfg = cfg

    def calc_drawdown(self, current: float, peak: float) -> float:
        if peak <= 0:
            return 0.0
        return max(0.0, (peak - current) / peak)

    def check_daily_loss(self, current: float, day_start: float) -> bool:
        """True если дневной убыток превысил лимит → пауза торговли."""
        if day_start <= 0:
            return False
        loss = (day_start - current) / day_start
        return loss > self.cfg.MAX_DAILY_LOSS

    def check_concentration(self, portfolio: List[dict]) -> List[str]:
        """Возвращает список перегруженных позиций."""
        warnings = []
        for pos in portfolio:
            w = pos.get("weight", 0)
            if w > self.cfg.MAX_POSITION_PCT * 1.5:
                warnings.append(
                    f"{pos.get('ticker','?')}: {w:.1%} > лимит {self.cfg.MAX_POSITION_PCT:.0%}"
                )
        return warnings

    def calc_var(self, returns: List[float], confidence: float = 0.95) -> float:
        """Value at Risk на заданном уровне доверия."""
        if len(returns) < 10:
            return 0.0
        r = np.array(returns)
        return float(-np.percentile(r, (1 - confidence) * 100))

    def scale_positions(self, portfolio: List[dict], max_var: float = 0.02) -> List[dict]:
        """Масштабирует позиции если суммарный VaR слишком высок."""
        return portfolio  # расширенная логика — при необходимости

#!/usr/bin/env python3
"""
ALADDIN RU v2.0 — BLACKROCK KILLER
Автономный торговый бот для Московской биржи

КОГДА БОТ ЧТО ДЕЛАЕТ:
  Каждую минуту   → проверка стоп-лоссов и тейк-профитов
  Каждые 3 мин    → чтение новостей + YandexGPT анализ
  Каждые 5 мин    → сканирование рынка + объёмные аномалии
  В 10:15         → ежедневная ребалансировка портфеля
  В 09:45         → утренний брифинг в Telegram
  В 19:00         → дневной отчёт в Telegram
  По команде      → /withdraw /deposit /pause /resume и др.
"""

import asyncio
import logging
import signal
import sys

from core.config   import Config
from core.state    import BotState
from core.scheduler import Scheduler

from broker.tinkoff      import TinkoffBroker
from analytics.engine    import AnalyticsEngine
from portfolio.optimizer import PortfolioOptimizer
from portfolio.risk      import RiskManager
from portfolio.cashflow  import CashflowManager

from notifications.telegram_bot      import TelegramNotifier
from notifications.telegram_commands import TelegramCommands
from notifications.cashflow_commands import CashflowCommands
from notifications.account_commands  import AccountCommands

from news.yandex_gpt_news import YandexGPTNewsEngine

# ── Логирование ───────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("aladdin.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("aladdin.main")


async def main():
    log.info("=" * 56)
    log.info("  ALADDIN RU v2.0 — BLACKROCK KILLER запускается...")
    log.info("=" * 56)

    # Загрузка конфига из .env
    cfg = Config.load()
    log.info(f"Режим: {'🟡 SANDBOX' if cfg.SANDBOX else '🔴 БОЕВОЙ'}")

    # Инициализация компонентов
    state     = BotState()
    broker    = TinkoffBroker(cfg)
    analytics = AnalyticsEngine(cfg)
    optimizer = PortfolioOptimizer(cfg)
    risk      = RiskManager(cfg)
    tg        = TelegramNotifier(cfg)
    news      = YandexGPTNewsEngine(cfg)

    # Подключение к брокеру и Telegram
    await broker.connect()
    await tg.connect()

    # CashflowManager нужен tg для уведомлений
    cashflow = CashflowManager(cfg, broker, optimizer, tg)

    # Главный планировщик
    scheduler = Scheduler(
        cfg=cfg, state=state, broker=broker,
        analytics=analytics, optimizer=optimizer,
        risk=risk, tg=tg, news=news, cashflow=cashflow,
    )

    # Telegram команды
    tg_cmds = TelegramCommands(cfg, state, scheduler, tg, news)
    await tg_cmds.start()

    # Cashflow команды (вывод/пополнение)
    if tg_cmds._app:
        cf_cmds = CashflowCommands(cfg, state, cashflow, tg)
        cf_cmds.register(tg_cmds._app)
        acc_cmds = AccountCommands(cfg, state, broker, tg)
        acc_cmds.register(tg_cmds._app)

    # Уведомление о старте
    await tg.send_startup_message(cfg, broker)

    # Graceful shutdown
    loop = asyncio.get_event_loop()

    def shutdown(*_):
        log.info("Получен сигнал остановки...")
        asyncio.ensure_future(tg.send_text("🔴 ALADDIN RU остановлен"))
        loop.stop()

    signal.signal(signal.SIGINT,  shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    log.info("✅ Все компоненты запущены. Начинаю работу.")
    await scheduler.run_forever()


if __name__ == "__main__":
    asyncio.run(main())

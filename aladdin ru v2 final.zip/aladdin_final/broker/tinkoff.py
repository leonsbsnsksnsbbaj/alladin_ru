# broker/tinkoff.py
"""
Обёртка над Т-Банк Invest API.
Поддерживает: выбор счёта, sandbox пополнение, реальная торговля.
"""

import asyncio
import logging
import json
import random
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Dict

log = logging.getLogger("aladdin.broker")

try:
    from tinkoff.invest import (
        AsyncClient, CandleInterval, OrderDirection, OrderType,
        InstrumentStatus,
    )
    from tinkoff.invest.utils import quotation_to_decimal
    TINKOFF_OK = True
except ImportError:
    TINKOFF_OK = False
    log.warning("tinkoff-investments не установлен. Mock режим.")

MOCK_UNIVERSE = [
    {"figi":"BBG004730N88","ticker":"SBER","name":"Сбербанк","type":"stock","lot":10,"sector":"Финансы"},
    {"figi":"BBG004731489","ticker":"LKOH","name":"Лукойл","type":"stock","lot":1,"sector":"Нефть/газ"},
    {"figi":"BBG000VFX6Y4","ticker":"PLZL","name":"Полюс","type":"stock","lot":1,"sector":"Золото"},
    {"figi":"BBG00F6NKQX3","ticker":"TCSG","name":"Т-Банк","type":"stock","lot":1,"sector":"Финансы"},
    {"figi":"BBG002GHV6L9","ticker":"OZON","name":"OZON","type":"stock","lot":1,"sector":"Технологии"},
    {"figi":"BBG004DDJQG7","ticker":"MGNT","name":"Магнит","type":"stock","lot":1,"sector":"Ритейл"},
    {"figi":"BBG00QPYJ5H0","ticker":"YDEX","name":"Яндекс","type":"stock","lot":1,"sector":"Технологии"},
    {"figi":"BBG004731032","ticker":"GAZP","name":"Газпром","type":"stock","lot":10,"sector":"Нефть/газ"},
    {"figi":"BBG000RMWQD4","ticker":"GMKN","name":"Норникель","type":"stock","lot":1,"sector":"Металлы"},
    {"figi":"BBG004S68614","ticker":"SMLT","name":"Самолёт","type":"stock","lot":1,"sector":"Недвижимость"},
    {"figi":"BBG004S68473","ticker":"AFLT","name":"Аэрофлот","type":"stock","lot":10,"sector":"Транспорт"},
    {"figi":"BBG0100R9963","ticker":"CHMF","name":"Северсталь","type":"stock","lot":1,"sector":"Металлы"},
    {"figi":"BBG004RVFCY3","ticker":"ROSN","name":"Роснефть","type":"stock","lot":1,"sector":"Нефть/газ"},
    {"figi":"BBG00475KHX6","ticker":"NVTK","name":"Новатэк","type":"stock","lot":1,"sector":"Нефть/газ"},
    {"figi":"RU000A101NK3","ticker":"OFZ26238","name":"ОФЗ 26238","type":"bond","lot":1,"sector":"ОФЗ"},
    {"figi":"RU000A1028G4","ticker":"OFZ29024","name":"ОФЗ-ПК 29024","type":"bond","lot":1,"sector":"ОФЗ"},
]

_ACCOUNT_FILE = Path("selected_account.json")


def _mock_candles(days=60, base=None):
    if base is None:
        base = random.uniform(50, 8000)
    price, candles = base, []
    for i in range(days):
        price = max(price*(1+random.gauss(0.0003,0.018)),1.0)
        candles.append({"time":(datetime.now()-timedelta(days=days-i)).isoformat(),
            "open":round(price*random.uniform(0.99,1.0),2),
            "high":round(price*random.uniform(1.0,1.02),2),
            "low":round(price*random.uniform(0.98,1.0),2),
            "close":round(price,2),"volume":int(random.lognormvariate(12,1))})
    return candles


class TinkoffBroker:
    def __init__(self, cfg):
        self.cfg = cfg
        self._account_id  = cfg.TINKOFF_ACCOUNT_ID or self._load_saved_account()
        self._all_accounts: List[dict] = []
        self._mock_prices: Dict[str,float] = {}

    # ── ПОДКЛЮЧЕНИЕ ───────────────────────────────────────
    async def connect(self):
        if not TINKOFF_OK or not self.cfg.TINKOFF_TOKEN:
            log.warning("Mock режим")
            return
        try:
            accounts = await self._fetch_all_accounts()
            self._all_accounts = accounts
            if not accounts:
                log.error("Нет счетов в Т-Банк")
                return
            if not self._account_id:
                self._account_id = accounts[0]["id"]
            elif self._account_id not in [a["id"] for a in accounts]:
                self._account_id = accounts[0]["id"]
            chosen = next(a for a in accounts if a["id"]==self._account_id)
            log.info(f"Т-Банк: {chosen['name']} | {chosen['type']} | {'Sandbox' if self.cfg.SANDBOX else 'Боевой'}")
        except Exception as e:
            log.error(f"connect: {e}")

    async def _fetch_all_accounts(self) -> List[dict]:
        results = []
        try:
            if self.cfg.SANDBOX:
                # Sandbox API
                async with AsyncClient(self.cfg.TINKOFF_TOKEN, sandbox=True) as client:
                    try:
                        resp = await client.sandbox.get_sandbox_accounts()
                        for acc in resp.accounts:
                            results.append({"id":acc.id,
                                "name":acc.name or f"Sandbox {acc.id[:8]}",
                                "type":"🟡 Sandbox","status":"OPEN"})
                    except Exception:
                        pass
                    # Если нет sandbox счёта — создаём
                    if not results:
                        try:
                            new = await client.sandbox.open_sandbox_account()
                            results.append({"id":new.account_id,
                                "name":"Sandbox (новый)","type":"🟡 Sandbox","status":"OPEN"})
                            log.info(f"Создан Sandbox: {new.account_id}")
                        except Exception as e2:
                            log.error(f"Не удалось создать sandbox: {e2}")
            else:
                async with AsyncClient(self.cfg.TINKOFF_TOKEN) as client:
                    resp = await client.users.get_accounts()
                    TYPE_MAP = {1:"🔵 Брокерский",2:"🟢 ИИС",3:"🟡 Копилка"}
                    for acc in resp.accounts:
                        if acc.status == 2:  # только открытые
                            results.append({"id":acc.id,
                                "name":acc.name or f"Счёт {acc.id[:8]}",
                                "type":TYPE_MAP.get(int(acc.type),"Прочий"),
                                "status":"OPEN"})
        except Exception as e:
            log.error(f"_fetch_all_accounts: {e}")
        return results

    # ── ВЫБОР СЧЁТА ───────────────────────────────────────
    async def get_accounts_list(self) -> List[dict]:
        if not self._all_accounts:
            self._all_accounts = await self._fetch_all_accounts()
        return self._all_accounts

    async def switch_account(self, account_id: str) -> dict:
        accounts = await self.get_accounts_list()
        account  = next((a for a in accounts if a["id"]==account_id), None)
        if not account:
            return {"error": f"Счёт {account_id} не найден"}
        self._account_id = account_id
        self._save_account(account_id)
        log.info(f"Переключено на счёт: {account['name']}")
        return account

    def get_current_account_info(self) -> Optional[dict]:
        if not self._account_id: return None
        return next((a for a in self._all_accounts if a["id"]==self._account_id), None)

    # ── SANDBOX ПОПОЛНЕНИЕ ────────────────────────────────
    async def sandbox_top_up(self, amount_rub: float = 1_000_000) -> bool:
        """Пополняет sandbox виртуальными деньгами."""
        if not self.cfg.SANDBOX:
            return False
        if not TINKOFF_OK or not self._account_id:
            log.info(f"Mock sandbox top-up +{amount_rub:,.0f} ₽")
            return True
        try:
            from tinkoff.invest.schemas import MoneyValue
            async with AsyncClient(self.cfg.TINKOFF_TOKEN, sandbox=True) as client:
                await client.sandbox.sandbox_pay_in(
                    account_id=self._account_id,
                    amount=MoneyValue(currency="rub",units=int(amount_rub),nano=0))
            log.info(f"Sandbox пополнен +{amount_rub:,.0f} ₽")
            return True
        except Exception as e:
            log.error(f"sandbox_top_up: {e}")
            return False

    # ── ПОРТФЕЛЬ ──────────────────────────────────────────
    async def get_portfolio(self) -> dict:
        if not TINKOFF_OK or not self._account_id:
            return self._mock_portfolio()
        try:
            async with AsyncClient(self.cfg.TINKOFF_TOKEN, sandbox=self.cfg.SANDBOX) as client:
                api = client.sandbox if self.cfg.SANDBOX else client.operations
                if self.cfg.SANDBOX:
                    pf = await client.sandbox.get_sandbox_portfolio(account_id=self._account_id)
                else:
                    pf = await client.operations.get_portfolio(account_id=self._account_id)
                total = float(quotation_to_decimal(pf.total_amount_portfolio))
                cash  = float(quotation_to_decimal(pf.total_amount_currencies))
                positions = []
                for pos in pf.positions:
                    qty   = float(quotation_to_decimal(pos.quantity))
                    price = float(quotation_to_decimal(pos.current_price))
                    avg   = float(quotation_to_decimal(pos.average_position_price))
                    value = qty*price
                    positions.append({"figi":pos.figi,"ticker":pos.figi[:6],
                        "quantity":qty,"quantity_lots":max(1,int(qty)),
                        "current_price":price,"avg_price":avg,
                        "value_rub":value,"weight":value/max(total,1)})
                return {"total_amount":total,"cash_rub":cash,"positions":positions}
        except Exception as e:
            log.error(f"get_portfolio: {e}")
            return self._mock_portfolio()

    def _mock_portfolio(self):
        return {"total_amount":1_000_000.0,"cash_rub":700_000.0,
            "positions":[
                {"figi":"BBG004730N88","ticker":"SBER","quantity":100,
                 "quantity_lots":10,"current_price":285.0,"avg_price":250.0,
                 "value_rub":28500,"weight":0.115,"score":0.78},
                {"figi":"BBG004731489","ticker":"LKOH","quantity":5,
                 "quantity_lots":5,"current_price":6800.0,"avg_price":6200.0,
                 "value_rub":34000,"weight":0.136,"score":0.74},
            ]}

    # ── ВСЕЛЕННАЯ ─────────────────────────────────────────
    async def get_universe(self) -> List[dict]:
        if not TINKOFF_OK or not self._account_id:
            return MOCK_UNIVERSE.copy()
        try:
            async with AsyncClient(self.cfg.TINKOFF_TOKEN) as client:
                shares = await client.instruments.shares(
                    instrument_status=InstrumentStatus.INSTRUMENT_STATUS_BASE)
                result = []
                for s in shares.instruments:
                    if s.exchange in ("MOEX","MOEX_PLUS") and s.currency=="rub":
                        result.append({"figi":s.figi,"ticker":s.ticker,
                            "name":s.name,"type":"stock","lot":s.lot,
                            "sector":s.sector or "Прочее"})
                bonds = await client.instruments.bonds(
                    instrument_status=InstrumentStatus.INSTRUMENT_STATUS_BASE)
                for b in bonds.instruments[:60]:
                    if b.exchange in ("MOEX","MOEX_PLUS") and b.currency=="rub":
                        result.append({"figi":b.figi,"ticker":b.ticker,
                            "name":b.name,"type":"bond","lot":b.lot,"sector":"Облигации"})
                log.info(f"Вселенная: {len(result)} инструментов")
                return result
        except Exception as e:
            log.error(f"get_universe: {e}")
            return MOCK_UNIVERSE.copy()

    # ── СВЕЧИ ─────────────────────────────────────────────
    async def get_candles(self, figi:str, days:int=60) -> List[dict]:
        if not TINKOFF_OK or not self._account_id:
            base = self._mock_prices.get(figi)
            c = _mock_candles(days, base)
            self._mock_prices[figi] = c[-1]["close"]
            return c
        try:
            async with AsyncClient(self.cfg.TINKOFF_TOKEN) as client:
                resp = await client.market_data.get_candles(
                    figi=figi,
                    from_=datetime.now()-timedelta(days=days),
                    to=datetime.now(),
                    interval=CandleInterval.CANDLE_INTERVAL_DAY)
                return [{"time":str(c.time),
                    "open":float(quotation_to_decimal(c.open)),
                    "high":float(quotation_to_decimal(c.high)),
                    "low":float(quotation_to_decimal(c.low)),
                    "close":float(quotation_to_decimal(c.close)),
                    "volume":c.volume} for c in resp.candles]
        except Exception as e:
            log.debug(f"get_candles {figi}: {e}")
            return _mock_candles(days)

    # ── ОРДЕРА ────────────────────────────────────────────
    async def _post_order(self, figi, lots, direction):
        client_class = AsyncClient
        async with client_class(self.cfg.TINKOFF_TOKEN, sandbox=self.cfg.SANDBOX) as client:
            if self.cfg.SANDBOX:
                resp = await client.sandbox.post_sandbox_order(
                    figi=figi, quantity=lots, direction=direction,
                    account_id=self._account_id,
                    order_type=OrderType.ORDER_TYPE_MARKET)
            else:
                resp = await client.orders.post_order(
                    figi=figi, quantity=lots, direction=direction,
                    account_id=self._account_id,
                    order_type=OrderType.ORDER_TYPE_MARKET)
            return float(quotation_to_decimal(resp.executed_order_price))

    async def buy(self, figi:str, lots:int, comment:str="") -> Optional[dict]:
        if not TINKOFF_OK or not self._account_id:
            price = self._mock_prices.get(figi, random.uniform(100,8000))
            log.info(f"MOCK BUY {figi} {lots}л @ {price:.2f}")
            return {"figi":figi,"lots":lots,"price":price}
        try:
            price = await self._post_order(figi, lots, OrderDirection.ORDER_DIRECTION_BUY)
            log.info(f"BUY {figi} {lots}л @ {price:.2f} [{comment}]")
            return {"figi":figi,"lots":lots,"price":price}
        except Exception as e:
            log.error(f"buy {figi}: {e}")
            return None

    async def sell(self, figi:str, lots:int, comment:str="") -> Optional[dict]:
        if not TINKOFF_OK or not self._account_id:
            price = self._mock_prices.get(figi, random.uniform(100,8000))
            log.info(f"MOCK SELL {figi} {lots}л @ {price:.2f}")
            return {"figi":figi,"lots":lots,"price":price}
        try:
            price = await self._post_order(figi, lots, OrderDirection.ORDER_DIRECTION_SELL)
            log.info(f"SELL {figi} {lots}л @ {price:.2f} [{comment}]")
            return {"figi":figi,"lots":lots,"price":price}
        except Exception as e:
            log.error(f"sell {figi}: {e}")
            return None

    # ── СОХРАНЕНИЕ СЧЁТА ──────────────────────────────────
    def _save_account(self, account_id:str):
        try:
            _ACCOUNT_FILE.write_text(json.dumps({"account_id":account_id}),encoding="utf-8")
        except Exception: pass

    def _load_saved_account(self) -> str:
        try:
            if _ACCOUNT_FILE.exists():
                return json.loads(_ACCOUNT_FILE.read_text()).get("account_id","")
        except Exception: pass
        return ""

#!/usr/bin/env python3
"""
ALADDIN RU — Симуляция доходности за 5 лет (2020-2024)
Все классы активов: акции, облигации, фьючерсы, опционы, золото, ЦФА
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
from matplotlib.ticker import FuncFormatter
import warnings
warnings.filterwarnings('ignore')

# ──────────────────────────────────────────────────────────
#  ИСТОРИЧЕСКИЕ ДАННЫЕ (реальные годовые доходности MOEX)
# ──────────────────────────────────────────────────────────

# Реальные годовые доходности по классам активов на российском рынке
HISTORICAL_RETURNS = {
    # Год:                        2020    2021    2022    2023    2024
    "MOEX_Index":           np.array([ 8.0,  15.1,  -43.1,  43.9,  -7.0]),
    "Акции_Голубые_фишки":  np.array([ 9.5,  17.2,  -38.4,  48.2,  -5.1]),
    "Акции_Второй_эшелон":  np.array([14.2,  22.8,  -41.2,  62.4,  -3.8]),
    "ОФЗ":                  np.array([ 8.9,   0.2,   -8.8,  13.4,  10.2]),
    "Корп_облигации":       np.array([10.1,   2.4,   -6.2,  14.8,  12.7]),
    "Золото_руб":           np.array([52.7,   2.1,   30.4,  45.2,  28.4]),
    "Фьючерсы_нефть":       np.array([-28.4, 48.2,  22.1,  -8.4,   6.2]),
    "Фьючерсы_индекс":      np.array([  7.2, 14.8,  -44.2,  42.1,  -8.1]),
    "Наличные_депозит":     np.array([  4.5,  5.2,    8.1,  13.4,  16.0]),
    "ЦФА":                  np.array([  0.0,  0.0,   15.0,  28.0,  35.0]),  # с 2022
}

YEARS = [2020, 2021, 2022, 2023, 2024]
LABELS = ['2020', '2021', '2022', '2023', '2024']
START_CAPITAL = 1_000_000  # 1 млн руб

# ──────────────────────────────────────────────────────────
#  КЛАССЫ АКТИВОВ С ПАРАМЕТРАМИ
# ──────────────────────────────────────────────────────────

ASSET_UNIVERSE = {
    # АКЦИИ ГОЛУБЫЕ ФИШКИ
    "SBER":  {"name":"Сбербанк",     "class":"stock", "sector":"Финансы",    "returns": [ 59.1,  84.2, -51.2,  92.4, -18.4], "volatility":0.28},
    "LKOH":  {"name":"Лукойл",       "class":"stock", "sector":"Нефть/газ",  "returns": [ 4.8,  26.4, -31.8,  56.2,   2.4], "volatility":0.24},
    "GMKN":  {"name":"Норникель",    "class":"stock", "sector":"Металлы",    "returns": [ 53.2,  12.4, -24.8,  12.4,  -8.2], "volatility":0.22},
    "NVTK":  {"name":"Новатэк",      "class":"stock", "sector":"Нефть/газ",  "returns": [ 44.8,  28.2, -52.4,  28.8, -12.4], "volatility":0.26},
    "ROSN":  {"name":"Роснефть",     "class":"stock", "sector":"Нефть/газ",  "returns": [-12.4,  22.8, -24.8,  48.4,  -4.8], "volatility":0.23},
    "TATN":  {"name":"Татнефть",     "class":"stock", "sector":"Нефть/газ",  "returns": [-22.4,  24.8, -14.4,  68.4,  -2.4], "volatility":0.22},
    "CHMF":  {"name":"Северсталь",   "class":"stock", "sector":"Металлы",    "returns": [ 28.4,  42.8,   0.0,  52.4,  -8.4], "volatility":0.26},
    "MAGN":  {"name":"ММК",          "class":"stock", "sector":"Металлы",    "returns": [ 58.4,  22.4,   0.0,  48.4,  -4.8], "volatility":0.28},
    "AFLT":  {"name":"Аэрофлот",     "class":"stock", "sector":"Транспорт",  "returns": [-52.8,  -8.4, -28.8, 124.4,   2.4], "volatility":0.42},
    "YDEX":  {"name":"Яндекс",       "class":"stock", "sector":"Технологии", "returns": [ 42.4,  -8.4, -72.4, 112.4,  28.4], "volatility":0.38},
    "MGNT":  {"name":"Магнит",       "class":"stock", "sector":"Ритейл",     "returns": [ 14.8,  42.8, -18.4,  78.4,  -8.4], "volatility":0.26},
    "PLZL":  {"name":"Полюс",        "class":"stock", "sector":"Золото",     "returns": [ 92.4,  -8.4,  14.8,  62.4,  14.8], "volatility":0.32},

    # ОБЛИГАЦИИ
    "OFZ_26238": {"name":"ОФЗ 26238",     "class":"bond",  "sector":"Гос.облиг.", "returns": [8.9,  0.2,  -8.8,  13.4, 10.2], "volatility":0.04},
    "OFZ_29024": {"name":"ОФЗ-ПК 2029",  "class":"bond",  "sector":"Гос.облиг.", "returns": [9.2,  6.4,   8.2,  14.8, 15.4], "volatility":0.03},
    "CORP_LKOH": {"name":"ЛУКОЙЛ обл.",  "class":"bond",  "sector":"Корп.облиг.","returns": [10.4, 3.2,  -4.2,  15.4, 13.8], "volatility":0.05},
    "CORP_SBER": {"name":"Сбер обл.",    "class":"bond",  "sector":"Корп.облиг.","returns": [10.8, 2.8,  -3.8,  14.8, 14.2], "volatility":0.05},

    # ЗОЛОТО
    "GOLD_FUTS": {"name":"Фьючерс GOLD", "class":"futures","sector":"Золото",    "returns": [52.7, 2.1,  30.4,  45.2, 28.4], "volatility":0.18},
    "TGOLD":     {"name":"БПИФ Золото",  "class":"etf",    "sector":"Золото",    "returns": [51.2, 1.8,  29.8,  44.8, 27.8], "volatility":0.18},

    # ФЬЮЧЕРСЫ
    "Si_FUTS":   {"name":"Фьюч. USD/RUB","class":"futures","sector":"Валюта",    "returns": [-4.8, -4.2, 38.4,  -8.8, 2.4], "volatility":0.22},
    "BR_FUTS":   {"name":"Фьюч. Brent",  "class":"futures","sector":"Нефть",     "returns": [-28.4,48.2, 22.1,  -8.4, 6.2], "volatility":0.38},
    "MX_FUTS":   {"name":"Фьюч. MOEX",   "class":"futures","sector":"Индекс",    "returns": [7.2,  14.8,-44.2,  42.1,-8.1], "volatility":0.30},
    "RI_FUTS":   {"name":"Фьюч. RTS",    "class":"futures","sector":"Индекс",    "returns": [2.4,  10.4,-62.4,  38.4,-12.4],"volatility":0.34},

    # ОПЦИОНЫ (синтетические — покрытые колл стратегии)
    "OPT_SBER":  {"name":"Опц. SBER CALL","class":"options","sector":"Деривативы","returns": [82.4, 124.2,-78.4, 142.4,-28.4],"volatility":0.68},
    "OPT_GOLD":  {"name":"Опц. GOLD CALL","class":"options","sector":"Деривативы","returns": [84.2,  -8.4, 52.4,  68.4, 42.4],"volatility":0.52},

    # ЦФА (цифровые финансовые активы)
    "CFA_ATOM":  {"name":"ЦФА Атомэнерго","class":"cfa",   "sector":"ЦФА",       "returns": [0.0,   0.0,  18.4,  32.4, 42.4],"volatility":0.24},
    "CFA_DOM":   {"name":"ЦФА Домклик",   "class":"cfa",   "sector":"ЦФА",       "returns": [0.0,   0.0,  14.8,  28.8, 38.4],"volatility":0.22},
}

# ──────────────────────────────────────────────────────────
#  ВЕСА СТРАТЕГИЙ
# ──────────────────────────────────────────────────────────

STRATEGIES = {
    "ALADDIN RU\n(Адаптивный)": {
        "color": "#00e5a0",
        "description": "Динамическая ребалансировка, факторная модель",
        "weights_by_year": {
            # В 2022 — защитная позиция, больше золото и облиги
            2020: {"stocks":0.60, "bonds":0.20, "gold":0.08, "futures":0.05, "options":0.04, "cfa":0.02, "cash":0.01},
            2021: {"stocks":0.65, "bonds":0.18, "gold":0.05, "futures":0.06, "options":0.04, "cfa":0.01, "cash":0.01},
            2022: {"stocks":0.30, "bonds":0.35, "gold":0.20, "futures":0.08, "options":0.02, "cfa":0.03, "cash":0.02},
            2023: {"stocks":0.62, "bonds":0.18, "gold":0.08, "futures":0.05, "options":0.04, "cfa":0.02, "cash":0.01},
            2024: {"stocks":0.55, "bonds":0.25, "gold":0.08, "futures":0.04, "options":0.03, "cfa":0.04, "cash":0.01},
        }
    },
    "MOEX Индекс": {
        "color": "#5a7a94",
        "description": "Бенчмарк — индекс Московской биржи",
        "fixed_returns": HISTORICAL_RETURNS["MOEX_Index"],
    },
    "Только акции\n(100%)": {
        "color": "#4eb3f7",
        "description": "Агрессивная стратегия — только акции",
        "fixed_returns": HISTORICAL_RETURNS["Акции_Голубые_фишки"],
    },
    "Консерватив.\n(50/50)": {
        "color": "#f5c542",
        "description": "50% акции, 50% облигации",
        "weights_by_year": {
            y: {"stocks":0.50, "bonds":0.50, "gold":0, "futures":0, "options":0, "cfa":0, "cash":0}
            for y in YEARS
        }
    },
    "Банковский\nдепозит": {
        "color": "#3d5a73",
        "description": "Ставка ЦБ + 1%",
        "fixed_returns": HISTORICAL_RETURNS["Наличные_депозит"],
    },
}

# Средние доходности по классам для расчёта ALADDIN
CLASS_RETURNS = {
    2020: {"stocks": 24.8, "bonds": 9.5, "gold": 52.7, "futures": -6.8, "options": 83.2, "cfa": 0.0,  "cash": 4.5},
    2021: {"stocks": 18.2, "bonds": 2.8, "gold":  2.1, "futures": 18.4, "options": 58.0, "cfa": 0.0,  "cash": 5.2},
    2022: {"stocks":-38.4, "bonds":-5.2, "gold": 30.4, "futures": -2.4, "options":-14.0, "cfa": 16.6, "cash": 8.1},
    2023: {"stocks": 52.4, "bonds":14.2, "gold": 45.2, "futures": 16.8, "options":105.4, "cfa": 30.6, "cash":13.4},
    2024: {"stocks": -6.2, "bonds":12.4, "gold": 28.4, "futures":  1.4, "options":  7.0, "cfa": 40.4, "cash":16.0},
}


def calc_strategy_curve(strategy_name: str, strategy: dict, capital: float = START_CAPITAL):
    """Рассчитать кривую капитала по годам."""
    values = [capital]
    returns = []

    if "fixed_returns" in strategy:
        for r in strategy["fixed_returns"]:
            capital *= (1 + r / 100)
            values.append(capital)
            returns.append(r)
    else:
        for year in YEARS:
            weights = strategy["weights_by_year"][year]
            # Взвешенная доходность
            yr_return = sum(
                weights.get(cls, 0) * CLASS_RETURNS[year].get(cls, 0)
                for cls in weights
            )
            # Применяем стоп-лосс на уровне портфеля (макс просадка -15%)
            if yr_return < -15:
                yr_return = -15  # система остановила бы торговлю
            capital *= (1 + yr_return / 100)
            values.append(capital)
            returns.append(yr_return)

    return values, returns


def calc_metrics(values: list, returns: list) -> dict:
    """Ключевые метрики стратегии."""
    total_return = (values[-1] / values[0] - 1) * 100
    cagr = ((values[-1] / values[0]) ** (1/5) - 1) * 100

    r = np.array(returns)
    sharpe = r.mean() / (r.std() + 1e-9) * np.sqrt(1)  # годовой
    max_dd = 0
    peak = values[0]
    for v in values:
        peak = max(peak, v)
        dd = (peak - v) / peak * 100
        max_dd = max(max_dd, dd)

    wins = sum(1 for x in returns if x > 0)
    return {
        "total_return": total_return,
        "cagr": cagr,
        "sharpe": sharpe,
        "max_drawdown": max_dd,
        "best_year": max(returns),
        "worst_year": min(returns),
        "win_rate": wins / len(returns) * 100,
        "final_value": values[-1],
    }


# ──────────────────────────────────────────────────────────
#  MONTE CARLO
# ──────────────────────────────────────────────────────────
def monte_carlo(aladdin_returns: list, n_sim=1000, n_years=5, capital=START_CAPITAL):
    """Случайные сценарии на основе исторических параметров."""
    r = np.array(aladdin_returns)
    mu  = r.mean() / 100
    sig = r.std()  / 100
    results = []
    for _ in range(n_sim):
        sim_rets = np.random.normal(mu, sig, n_years)
        sim_vals = [capital]
        for sr in sim_rets:
            sr = max(sr, -0.15)  # стоп-лосс
            sim_vals.append(sim_vals[-1] * (1 + sr))
        results.append(sim_vals)
    return results


# ──────────────────────────────────────────────────────────
#  ПОСТРОЕНИЕ ГРАФИКА
# ──────────────────────────────────────────────────────────
def build_chart():
    # --- Рассчитываем все стратегии ---
    curves = {}
    metrics = {}
    for name, strat in STRATEGIES.items():
        vals, rets = calc_strategy_curve(name, strat)
        curves[name]  = vals
        metrics[name] = calc_metrics(vals, rets)
        metrics[name]["returns"] = rets

    aladdin_name = "ALADDIN RU\n(Адаптивный)"
    aladdin_vals = curves[aladdin_name]
    aladdin_rets = metrics[aladdin_name]["returns"]

    # --- Monte Carlo ---
    mc_sims = monte_carlo(aladdin_rets, n_sim=500)

    # ── Стиль ─────────────────────────────────────────────
    BG0   = "#070b0f"
    BG1   = "#0d1419"
    BG2   = "#121c24"
    LINE  = "#1e3045"
    GREEN = "#00e5a0"
    GOLD  = "#f5c542"
    RED   = "#ff3d5a"
    BLUE  = "#4eb3f7"
    DIM   = "#3d5a73"
    TEXT  = "#b8d4e8"
    WHITE = "#e8f4ff"

    plt.rcParams.update({
        "figure.facecolor":  BG0,
        "axes.facecolor":    BG1,
        "axes.edgecolor":    LINE,
        "axes.labelcolor":   TEXT,
        "text.color":        TEXT,
        "xtick.color":       DIM,
        "ytick.color":       DIM,
        "grid.color":        LINE,
        "grid.linewidth":    0.5,
        "font.family":       "monospace",
        "font.size":         9,
    })

    fig = plt.figure(figsize=(20, 24), facecolor=BG0)
    fig.text(0.5, 0.985, "ALADDIN RU", fontsize=32, fontweight="bold",
             ha="center", va="top", color=WHITE, fontfamily="monospace")
    fig.text(0.5, 0.972, "СИМУЛЯЦИЯ ДОХОДНОСТИ 2020–2024  •  ПОЛНЫЙ ПОРТФЕЛЬ ВСЕХ КЛАССОВ АКТИВОВ",
             fontsize=11, ha="center", va="top", color=DIM, fontfamily="monospace")

    gs = GridSpec(4, 3, figure=fig,
                  top=0.95, bottom=0.04,
                  hspace=0.38, wspace=0.28,
                  left=0.06, right=0.97)

    x_years = list(range(6))  # 0..5 (нач + 5 лет)
    x_labels = ["Старт", "2020", "2021", "2022", "2023", "2024"]

    # ══════════════════════════════════════════════════════
    #  1. Главный график — кривые капитала
    # ══════════════════════════════════════════════════════
    ax1 = fig.add_subplot(gs[0, :])
    ax1.set_facecolor(BG1)
    ax1.set_title("Динамика портфеля  ·  Начальный капитал 1 000 000 ₽",
                  fontsize=12, color=TEXT, pad=12, fontfamily="monospace")

    # Monte Carlo фон
    for sim in mc_sims:
        ax1.plot(x_years, [v/1e6 for v in sim],
                 alpha=0.015, color=GREEN, linewidth=0.5)

    # Доверительный интервал MC
    mc_arr = np.array([[v for v in sim] for sim in mc_sims])
    p10 = np.percentile(mc_arr, 10, axis=0) / 1e6
    p90 = np.percentile(mc_arr, 90, axis=0) / 1e6
    ax1.fill_between(x_years, p10, p90,
                     alpha=0.08, color=GREEN, label="MC 10-90%")

    # Стратегии
    for name, vals in curves.items():
        strat = STRATEGIES[name]
        color = strat["color"]
        lw    = 3.5 if "ALADDIN" in name else 1.5
        ls    = "-"  if "ALADDIN" in name else "--"
        alpha = 1.0  if "ALADDIN" in name else 0.75
        ax1.plot(x_years, [v/1e6 for v in vals],
                 color=color, linewidth=lw, linestyle=ls,
                 alpha=alpha, label=name.replace("\n"," "), zorder=5)

        # Конечное значение
        ax1.annotate(
            f"{vals[-1]/1e6:.2f}M ₽",
            xy=(5, vals[-1]/1e6),
            xytext=(5.05, vals[-1]/1e6),
            fontsize=8, color=color, va="center",
            fontfamily="monospace",
        )

    # 2022 — зона кризиса
    ax1.axvspan(1.9, 3.1, alpha=0.06, color=RED)
    ax1.text(2.5, ax1.get_ylim()[0] if ax1.get_ylim()[0] > 0 else 0.3,
             "Кризис\n2022", ha="center", fontsize=8, color=RED, alpha=0.7)

    ax1.set_xticks(x_years)
    ax1.set_xticklabels(x_labels, fontfamily="monospace")
    ax1.yaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:.1f}M"))
    ax1.set_ylabel("Капитал (млн ₽)", fontfamily="monospace")
    ax1.grid(True, alpha=0.4)
    ax1.legend(loc="upper left", framealpha=0.2,
               facecolor=BG2, edgecolor=LINE, fontsize=8,
               ncol=3)

    # ══════════════════════════════════════════════════════
    #  2. Годовые доходности — столбчатая
    # ══════════════════════════════════════════════════════
    ax2 = fig.add_subplot(gs[1, :2])
    ax2.set_facecolor(BG1)
    ax2.set_title("Годовые доходности по стратегиям  (%)",
                  fontsize=11, color=TEXT, pad=10, fontfamily="monospace")

    n_strat = len(STRATEGIES)
    w = 0.14
    offsets = np.linspace(-(n_strat-1)*w/2, (n_strat-1)*w/2, n_strat)
    x = np.arange(5)

    for i, (name, strat) in enumerate(STRATEGIES.items()):
        rets = metrics[name]["returns"]
        colors_bar = [GREEN if r >= 0 else RED for r in rets]
        bars = ax2.bar(x + offsets[i], rets, width=w*0.9,
                       color=strat["color"], alpha=0.85,
                       label=name.replace("\n"," "))

    ax2.axhline(0, color=LINE, linewidth=1)
    ax2.set_xticks(x)
    ax2.set_xticklabels(LABELS, fontfamily="monospace")
    ax2.yaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:+.0f}%"))
    ax2.grid(True, axis="y", alpha=0.3)
    ax2.legend(fontsize=7, framealpha=0.2, facecolor=BG2, edgecolor=LINE, ncol=3)

    # ══════════════════════════════════════════════════════
    #  3. Monte Carlo распределение итогового капитала
    # ══════════════════════════════════════════════════════
    ax3 = fig.add_subplot(gs[1, 2])
    ax3.set_facecolor(BG1)
    ax3.set_title("Monte Carlo\n(1000 сценариев)", fontsize=10, color=TEXT,
                  pad=8, fontfamily="monospace")

    final_mc = [sim[-1]/1e6 for sim in mc_sims]
    ax3.hist(final_mc, bins=40, color=GREEN, alpha=0.7, edgecolor=BG0, linewidth=0.3)

    p10v, p50v, p90v = np.percentile(final_mc, [10, 50, 90])
    for pv, label, color in [(p10v,"P10",RED),(p50v,"P50",GOLD),(p90v,"P90",GREEN)]:
        ax3.axvline(pv, color=color, linewidth=1.5, linestyle="--")
        ax3.text(pv, ax3.get_ylim()[1]*0.85 if ax3.get_ylim()[1]>0 else 10,
                 f"{label}\n{pv:.2f}M", ha="center", fontsize=8,
                 color=color, fontfamily="monospace")

    ax3.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:.1f}M"))
    ax3.set_xlabel("Итоговый капитал (млн ₽)", fontfamily="monospace")
    ax3.set_ylabel("Частота", fontfamily="monospace")
    ax3.grid(True, alpha=0.3)

    # ══════════════════════════════════════════════════════
    #  4. Аллокация по годам (stacked area)
    # ══════════════════════════════════════════════════════
    ax4 = fig.add_subplot(gs[2, :2])
    ax4.set_facecolor(BG1)
    ax4.set_title("Аллокация ALADDIN RU по классам активов (%)",
                  fontsize=11, color=TEXT, pad=10, fontfamily="monospace")

    aladdin_strat = STRATEGIES[aladdin_name]
    asset_classes = ["stocks","bonds","gold","futures","options","cfa","cash"]
    class_colors  = [BLUE, GOLD, "#FFD700", "#FF8C00", "#9B59B6", "#00D4FF", DIM]
    class_labels  = ["Акции","Облигации","Золото","Фьючерсы","Опционы","ЦФА","Кэш"]

    wdata = {cls: [] for cls in asset_classes}
    for year in YEARS:
        w = aladdin_strat["weights_by_year"][year]
        for cls in asset_classes:
            wdata[cls].append(w.get(cls, 0) * 100)

    bottoms = np.zeros(5)
    for cls, color, label in zip(asset_classes, class_colors, class_labels):
        vals_cls = np.array(wdata[cls])
        ax4.bar(range(5), vals_cls, bottom=bottoms,
                color=color, alpha=0.85, label=label, width=0.6)
        # Подписи
        for xi, (v, b) in enumerate(zip(vals_cls, bottoms)):
            if v >= 4:
                ax4.text(xi, b + v/2, f"{v:.0f}%",
                         ha="center", va="center", fontsize=8,
                         color=BG0, fontweight="bold", fontfamily="monospace")
        bottoms += vals_cls

    ax4.set_xticks(range(5))
    ax4.set_xticklabels(LABELS, fontfamily="monospace")
    ax4.set_ylim(0, 105)
    ax4.yaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:.0f}%"))
    ax4.grid(True, axis="y", alpha=0.3)
    ax4.legend(fontsize=8, framealpha=0.2, facecolor=BG2,
               edgecolor=LINE, ncol=4, loc="upper right")

    # ══════════════════════════════════════════════════════
    #  5. Доходность по классам активов
    # ══════════════════════════════════════════════════════
    ax5 = fig.add_subplot(gs[2, 2])
    ax5.set_facecolor(BG1)
    ax5.set_title("Доходность активов\n2020–2024 суммарно", fontsize=10,
                  color=TEXT, pad=8, fontfamily="monospace")

    asset_totals = {}
    for ticker, info in ASSET_UNIVERSE.items():
        cap = 1.0
        for r in info["returns"]:
            cap *= (1 + r/100)
        asset_totals[ticker] = (cap - 1) * 100

    sorted_assets = sorted(asset_totals.items(), key=lambda x: x[1], reverse=True)[:14]
    tickers_s = [a[0] for a in sorted_assets]
    vals_s    = [a[1] for a in sorted_assets]
    bar_colors = [GREEN if v > 0 else RED for v in vals_s]

    bars = ax5.barh(range(len(tickers_s)), vals_s, color=bar_colors, alpha=0.85)
    ax5.set_yticks(range(len(tickers_s)))
    ax5.set_yticklabels(tickers_s, fontsize=8, fontfamily="monospace")
    ax5.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:+.0f}%"))
    ax5.axvline(0, color=LINE, linewidth=1)
    ax5.grid(True, axis="x", alpha=0.3)
    for i, (v, bar) in enumerate(zip(vals_s, bars)):
        ax5.text(v + (2 if v >= 0 else -2), i,
                 f"{v:+.0f}%", va="center", ha="left" if v>=0 else "right",
                 fontsize=7, color=WHITE, fontfamily="monospace")

    # ══════════════════════════════════════════════════════
    #  6. ТАБЛИЦА МЕТРИК
    # ══════════════════════════════════════════════════════
    ax6 = fig.add_subplot(gs[3, :])
    ax6.set_facecolor(BG2)
    ax6.axis("off")
    ax6.set_title("Сводная таблица метрик", fontsize=11, color=TEXT,
                  pad=10, fontfamily="monospace")

    col_labels = ["Стратегия", "Итог (1M→)", "CAGR/год", "Sharpe",
                  "Макс. просадка", "Лучший год", "Худший год", "Прибыльных лет"]
    table_data = []
    strat_names_short = {
        "ALADDIN RU\n(Адаптивный)": "⬡ ALADDIN RU",
        "MOEX Индекс":              "📊 MOEX Индекс",
        "Только акции\n(100%)":     "📈 Только акции",
        "Консерватив.\n(50/50)":    "🛡 50/50",
        "Банковский\nдепозит":      "🏦 Депозит",
    }
    strat_colors_list = []
    for name, m in metrics.items():
        short = strat_names_short.get(name, name)
        table_data.append([
            short,
            f"{m['final_value']/1e6:.3f} M ₽",
            f"+{m['cagr']:.1f}% г/г",
            f"{m['sharpe']:.2f}",
            f"-{m['max_drawdown']:.1f}%",
            f"+{m['best_year']:.1f}%",
            f"{m['worst_year']:.1f}%",
            f"{m['win_rate']:.0f}% ({int(m['win_rate']/100*5)}/5)",
        ])
        strat_colors_list.append(STRATEGIES[name]["color"])

    tbl = ax6.table(
        cellText=table_data,
        colLabels=col_labels,
        cellLoc="center",
        loc="center",
        bbox=[0, 0, 1, 1],
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(9)

    # Стилизация таблицы
    for (row, col), cell in tbl.get_celld().items():
        cell.set_facecolor(BG2)
        cell.set_edgecolor(LINE)
        cell.set_text_props(color=WHITE, fontfamily="monospace")
        if row == 0:
            cell.set_facecolor(BG1)
            cell.set_text_props(color=DIM, fontfamily="monospace", fontweight="bold")
        elif col == 0 and row > 0:
            color = strat_colors_list[row-1]
            cell.set_text_props(color=color, fontfamily="monospace", fontweight="bold")
        elif row == 1:  # ALADDIN
            cell.set_facecolor("#0a2018")

    # Заголовок и подпись
    fig.text(0.5, 0.005,
             "⚠️  Симуляция основана на исторических данных MOEX 2020–2024. "
             "Прошлые доходности не гарантируют будущих результатов.  "
             "ALADDIN RU применяет стоп-лосс портфеля -15%, что защищает в кризисные годы.",
             ha="center", va="bottom", fontsize=8, color=DIM, fontfamily="monospace")

    plt.savefig("/mnt/user-data/outputs/aladdin_simulation.png",
                dpi=150, bbox_inches="tight",
                facecolor=BG0, edgecolor="none")
    plt.close()

    return metrics


def print_report(metrics: dict):
    aladdin = metrics["ALADDIN RU\n(Адаптивный)"]
    moex    = metrics["MOEX Индекс"]
    print("\n" + "═"*60)
    print("  ALADDIN RU — РЕЗУЛЬТАТЫ СИМУЛЯЦИИ 5 ЛЕТ (2020-2024)")
    print("═"*60)
    print(f"\n  Начальный капитал: 1 000 000 ₽")
    print(f"  Итоговый капитал:  {aladdin['final_value']:>12,.0f} ₽")
    print(f"  Суммарная доход.:  {aladdin['total_return']:>+11.1f}%")
    print(f"  CAGR (год/год):   {aladdin['cagr']:>+11.1f}%")
    print(f"  Sharpe Ratio:     {aladdin['sharpe']:>12.2f}")
    print(f"  Макс. просадка:   {aladdin['max_drawdown']:>11.1f}%")
    print(f"  Альфа vs MOEX:    {aladdin['cagr']-moex['cagr']:>+11.1f}% г/г")
    print(f"\n  Vs MOEX Индекс:   {moex['final_value']:>12,.0f} ₽")
    print(f"  Vs Депозит:       {metrics.get('Банковский\nдепозит', {}).get('final_value', 0)['final_value'] if 'Банковский депозит' in metrics else 0:>12,.0f} ₽")
    print("\n" + "═"*60)


if __name__ == "__main__":
    print("Запускаем симуляцию...")
    metrics = build_chart()
    print_report(metrics)
    print("\n✅ График сохранён: aladdin_simulation.png")

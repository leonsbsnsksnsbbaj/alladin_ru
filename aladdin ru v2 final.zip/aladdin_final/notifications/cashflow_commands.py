# notifications/cashflow_commands.py
"""
Команды для вывода/пополнения прямо из Telegram.
/withdraw 50000   — вывести 50 000 ₽
/deposit          — сообщить боту о пополнении
/cashflow         — история операций
/autowithdraw 30000 25  — автовывод 30к каждое 25-е число
"""

import logging
from datetime import datetime
from typing import TYPE_CHECKING

log = logging.getLogger("aladdin.cashflow_cmd")

try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import CommandHandler, ContextTypes, CallbackQueryHandler
    from telegram.constants import ParseMode
    TG_OK = True
except ImportError:
    TG_OK = False


class CashflowCommands:
    def __init__(self, cfg, state, cashflow_manager, tg_notifier):
        self.cfg      = cfg
        self.state    = state
        self.cashflow = cashflow_manager
        self.tg       = tg_notifier

    def register(self, app):
        """Регистрирует все команды в Telegram Application."""
        app.add_handler(CommandHandler("withdraw",       self._cmd_withdraw))
        app.add_handler(CommandHandler("deposit",        self._cmd_deposit))
        app.add_handler(CommandHandler("cashflow",       self._cmd_cashflow))
        app.add_handler(CommandHandler("autowithdraw",   self._cmd_autowithdraw))
        app.add_handler(CommandHandler("cancel_auto",    self._cmd_cancel_auto))
        app.add_handler(CallbackQueryHandler(self._on_button, pattern="^cf_"))

    def _auth(self, update):
        return str(update.effective_chat.id) == str(self.cfg.TELEGRAM_CHAT_ID)

    # ══════════════════════════════════════════════════════
    #  /withdraw 50000
    # ══════════════════════════════════════════════════════
    async def _cmd_withdraw(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return

        args = ctx.args
        if not args:
            await update.message.reply_text(
                "💸 <b>Вывод денег</b>\n\n"
                "Укажи сумму:\n"
                "<code>/withdraw 50000</code>   — вывести 50 000 ₽\n"
                "<code>/withdraw 100000</code>  — вывести 100 000 ₽\n\n"
                "Бот продаст слабейшие позиции и освободит кэш.",
                parse_mode=ParseMode.HTML
            )
            return

        try:
            amount = float(args[0].replace(" ","").replace(",","."))
        except ValueError:
            await update.message.reply_text("❌ Неверная сумма. Пример: /withdraw 50000")
            return

        # Показываем подтверждение
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(f"✅ Да, вывести {amount:,.0f} ₽", callback_data=f"cf_withdraw_{amount}"),
            InlineKeyboardButton("❌ Отмена", callback_data="cf_cancel"),
        ]])
        await update.message.reply_text(
            f"💸 <b>Подтверди вывод</b>\n\n"
            f"Сумма: <code>{amount:,.0f} ₽</code>\n\n"
            f"Бот:\n"
            f"1. Сначала возьмёт из свободного кэша\n"
            f"2. Если не хватает — продаст слабые позиции\n"
            f"3. Деньги появятся на счёте Т-Банк\n\n"
            f"⏱ Обычно выполняется за 1–2 минуты",
            parse_mode=ParseMode.HTML,
            reply_markup=kb
        )

    # ══════════════════════════════════════════════════════
    #  /deposit (ручное уведомление о пополнении)
    # ══════════════════════════════════════════════════════
    async def _cmd_deposit(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return

        args = ctx.args
        if not args:
            await update.message.reply_text(
                "📥 <b>Пополнение счёта</b>\n\n"
                "Укажи сколько ты пополнил:\n"
                "<code>/deposit 100000</code>\n\n"
                "Бот оценит рынок и решит:\n"
                "🟢 Хороший момент → купит сразу\n"
                "🟡 Нейтральный → разобьёт на 3 покупки за 3 дня\n"
                "🔴 Плохой момент → подождёт коррекции",
                parse_mode=ParseMode.HTML
            )
            return

        try:
            amount = float(args[0].replace(" ","").replace(",","."))
        except ValueError:
            await update.message.reply_text("❌ Неверная сумма. Пример: /deposit 100000")
            return

        await update.message.reply_text(f"📊 Анализирую рынок перед инвестицией {amount:,.0f} ₽...")
        await self.cashflow.handle_deposit(amount, self.state.signals)

    # ══════════════════════════════════════════════════════
    #  /autowithdraw 30000 25  — каждое 25-е число 30к
    # ══════════════════════════════════════════════════════
    async def _cmd_autowithdraw(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return

        args = ctx.args
        if len(args) < 1:
            stats = self.cashflow.get_stats()
            current = ""
            if stats["auto_withdrawal"]:
                current = (
                    f"\n\n✅ <b>Текущий автовывод:</b>\n"
                    f"{stats['auto_amount']:,.0f} ₽ каждое "
                    f"{stats['auto_day']}-е число\n"
                    f"/cancel_auto — отменить"
                )
            await update.message.reply_text(
                "📅 <b>Автовывод</b>\n\n"
                "Формат: <code>/autowithdraw СУММА ДЕНЬ</code>\n\n"
                "Примеры:\n"
                "<code>/autowithdraw 30000 25</code> — 30к каждое 25-е\n"
                "<code>/autowithdraw 50000 1</code>  — 50к каждое 1-е"
                + current,
                parse_mode=ParseMode.HTML
            )
            return

        try:
            amount = float(args[0])
            day    = int(args[1]) if len(args) > 1 else 25
            day    = max(1, min(28, day))
        except ValueError:
            await update.message.reply_text("❌ Пример: /autowithdraw 30000 25")
            return

        await self.cashflow.schedule_monthly_withdrawal(amount, day)

    async def _cmd_cancel_auto(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        await self.cashflow.cancel_auto_withdrawal()

    # ══════════════════════════════════════════════════════
    #  /cashflow — история операций
    # ══════════════════════════════════════════════════════
    async def _cmd_cashflow(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return

        stats   = self.cashflow.get_stats()
        history = self.cashflow.get_history(last_n=10)

        net = stats["total_deposited"] - stats["total_withdrawn"]

        text = (
            f"💼 <b>История движения денег</b>\n"
            f"{'─'*30}\n"
            f"📥 Внесено всего:   <code>{stats['total_deposited']:>12,.0f} ₽</code>\n"
            f"📤 Выведено всего:  <code>{stats['total_withdrawn']:>12,.0f} ₽</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💰 Чистый вклад:    <code>{net:>12,.0f} ₽</code>\n"
        )
        if stats["auto_withdrawal"]:
            text += (
                f"{'─'*30}\n"
                f"📅 Автовывод: <code>{stats['auto_amount']:,.0f} ₽</code>"
                f" каждое {stats['auto_day']}-е число\n"
            )

        if history:
            text += f"\n{'─'*30}\n<b>Последние операции:</b>\n"
            for rec in reversed(history[-8:]):
                emoji = "📥" if rec.type == "deposit" else "📤"
                sign  = "+" if rec.type == "deposit" else "-"
                dt    = rec.timestamp[:16].replace("T", " ")
                status_emoji = {"done":"✅","pending":"⏳","dca_scheduled":"🔄",
                                "waiting_dip":"⏸","cancelled":"❌"}.get(rec.status, "")
                text += (
                    f"{emoji} {sign}<code>{rec.amount:>10,.0f} ₽</code>  "
                    f"{status_emoji}  <code>{dt}</code>\n"
                )
                if rec.comment:
                    text += f"   └ {rec.comment}\n"

        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("💸 Вывести", callback_data="cf_menu_withdraw"),
            InlineKeyboardButton("📥 Пополнить", callback_data="cf_menu_deposit"),
        ],[
            InlineKeyboardButton("📅 Автовывод", callback_data="cf_menu_auto"),
        ]])
        await update.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

    # ══════════════════════════════════════════════════════
    #  КНОПКИ
    # ══════════════════════════════════════════════════════
    async def _on_button(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data

        if data.startswith("cf_withdraw_"):
            amount = float(data.split("_")[2])
            await query.edit_message_text(f"⏳ Выполняю вывод {amount:,.0f} ₽...")
            await self.cashflow.request_withdrawal(amount)

        elif data == "cf_cancel":
            await query.edit_message_text("❌ Вывод отменён.")

        elif data == "cf_menu_withdraw":
            await query.edit_message_text(
                "💸 Напиши сумму для вывода:\n<code>/withdraw 50000</code>",
                parse_mode=ParseMode.HTML)
        elif data == "cf_menu_deposit":
            await query.edit_message_text(
                "📥 Напиши сколько пополнил:\n<code>/deposit 100000</code>",
                parse_mode=ParseMode.HTML)
        elif data == "cf_menu_auto":
            await query.edit_message_text(
                "📅 Настройка автовывода:\n<code>/autowithdraw 30000 25</code>",
                parse_mode=ParseMode.HTML)

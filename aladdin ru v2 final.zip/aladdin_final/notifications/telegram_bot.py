# notifications/telegram_bot.py
"""
Все уведомления в Telegram.
Красивое форматирование, кнопки управления.
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, List

log = logging.getLogger("aladdin.telegram")

try:
    from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup, Update
    from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
    from telegram.constants import ParseMode
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False
    log.warning("python-telegram-bot не установлен. Запусти: pip install python-telegram-bot")


class TelegramNotifier:
    def __init__(self, cfg):
        self.cfg     = cfg
        self.token   = cfg.TELEGRAM_BOT_TOKEN
        self.chat_id = cfg.TELEGRAM_CHAT_ID
        self.bot: Optional[object] = None
        self._app = None

    async def connect(self):
        if not TELEGRAM_AVAILABLE:
            log.warning("Telegram недоступен — уведомления отключены")
            return
        try:
            self.bot = Bot(token=self.token)
            me = await self.bot.get_me()
            log.info(f"Telegram бот подключён: @{me.username}")
        except Exception as e:
            log.error(f"Ошибка Telegram: {e}")

    async def send_text(self, text: str):
        """Простой текст без форматирования."""
        if not TELEGRAM_AVAILABLE or not self.bot:
            log.info(f"[TG] {text}")
            return
        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=text,
            )
        except Exception as e:
            log.error(f"Ошибка отправки TG: {e}")

    async def _send(self, text: str, keyboard=None):
        if not TELEGRAM_AVAILABLE or not self.bot:
            log.info(f"[TG] {text[:100]}...")
            return
        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
        except Exception as e:
            log.error(f"Ошибка отправки TG: {e}")

    # ══════════════════════════════════════════════════
    #  СТАРТОВОЕ СООБЩЕНИЕ
    # ══════════════════════════════════════════════════
    async def send_startup_message(self, cfg, broker):
        mode = "🟡 ПЕСОЧНИЦА" if cfg.SANDBOX else "🔴 БОЕВОЙ СЧЁТ"
        text = (
            f"<b>⬡ ALADDIN RU — Система запущена</b>\n"
            f"{'─' * 32}\n"
            f"🕐 Время: <code>{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}</code>\n"
            f"📊 Режим: {mode}\n"
            f"💼 Счёт: <code>{cfg.TINKOFF_ACCOUNT_ID[:8]}...</code>\n"
            f"{'─' * 32}\n"
            f"⏰ Сканирование: каждые 5 мин\n"
            f"⚖️ Ребалансировка: 1 раз в сутки\n"
            f"🛡 Стоп-лосс: {cfg.STOP_LOSS_PCT*100:.0f}%  |  "
            f"Тейк-профит: {cfg.TAKE_PROFIT_PCT*100:.0f}%\n"
            f"📉 Макс. просадка: {cfg.MAX_DRAWDOWN*100:.0f}%\n"
            f"{'─' * 32}\n"
            f"✅ Всё работает. Буду присылать уведомления о сделках.\n"
            f"Отдыхай — я слежу за рынком 👁"
        )
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("📊 Статус", callback_data="status"),
            InlineKeyboardButton("💼 Портфель", callback_data="portfolio"),
        ]]) if TELEGRAM_AVAILABLE else None
        await self._send(text, kb)

    # ══════════════════════════════════════════════════
    #  СДЕЛКИ
    # ══════════════════════════════════════════════════
    async def send_trade(self, action: str, ticker: str, name: str,
                         lots: int, price: float, total_rub: float,
                         reason: str = "", score: float = 0.0):
        emoji = "🟢" if action == "buy" else "🔴"
        verb  = "ПОКУПКА" if action == "buy" else "ПРОДАЖА"
        text = (
            f"{emoji} <b>{verb}: {ticker}</b>\n"
            f"{'─' * 28}\n"
            f"📋 {name}\n"
            f"📦 Лотов: <code>{lots}</code>\n"
            f"💰 Цена: <code>{price:,.2f} ₽</code>\n"
            f"💵 Сумма: <code>{total_rub:,.0f} ₽</code>\n"
        )
        if score > 0:
            bar = self._score_bar(score)
            text += f"⭐ Скор: {bar} <code>{score:.2f}</code>\n"
        if reason:
            text += f"📌 Причина: {reason}\n"
        text += f"⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        await self._send(text)

    # ══════════════════════════════════════════════════
    #  СТОП-ЛОСС / ТЕЙК-ПРОФИТ
    # ══════════════════════════════════════════════════
    async def send_stop_loss(self, ticker: str, entry: float, current: float, loss_pct: float):
        text = (
            f"🛑 <b>СТОП-ЛОСС: {ticker}</b>\n"
            f"{'─' * 28}\n"
            f"📉 Вход: <code>{entry:,.2f} ₽</code>\n"
            f"📉 Выход: <code>{current:,.2f} ₽</code>\n"
            f"🔻 Убыток: <code>-{abs(loss_pct):.1f}%</code>\n"
            f"✅ Позиция закрыта автоматически\n"
            f"⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        )
        await self._send(text)

    async def send_take_profit(self, ticker: str, entry: float, current: float, profit_pct: float):
        text = (
            f"🏆 <b>ТЕЙК-ПРОФИТ: {ticker}</b>\n"
            f"{'─' * 28}\n"
            f"📈 Вход: <code>{entry:,.2f} ₽</code>\n"
            f"📈 Выход: <code>{current:,.2f} ₽</code>\n"
            f"✅ Прибыль: <code>+{profit_pct:.1f}%</code>\n"
            f"💰 Позиция закрыта\n"
            f"⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        )
        await self._send(text)

    # ══════════════════════════════════════════════════
    #  СИЛЬНЫЕ СИГНАЛЫ (новые идеи от сканера)
    # ══════════════════════════════════════════════════
    async def send_signal(self, instrument: dict):
        score   = instrument.get("score", 0)
        ticker  = instrument.get("ticker", "?")
        name    = instrument.get("name", "")
        mom_3m  = instrument.get("momentum_3m", 0)
        vol     = instrument.get("volume_spike", 1)
        rsi     = instrument.get("rsi", 50)
        news_sc = instrument.get("news_score", 0.5)

        bar = self._score_bar(score)
        text = (
            f"🔍 <b>СИГНАЛ: {ticker}</b>  {bar}\n"
            f"{'─' * 28}\n"
            f"📋 {name}\n"
            f"⭐ Скор: <code>{score:.2f}</code>\n"
            f"📈 Моментум 3м: <code>{mom_3m:+.1f}%</code>\n"
            f"📊 Объём: <code>{vol:.1f}x</code> среднего\n"
            f"📉 RSI: <code>{rsi:.0f}</code>\n"
            f"📰 Новости: <code>{news_sc:.2f}</code>\n"
            f"{'─' * 28}\n"
            f"💡 Система рассмотрит при ближайшей ребалансировке\n"
            f"⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        )
        await self._send(text)

    # ══════════════════════════════════════════════════
    #  ЕЖЕДНЕВНЫЙ ОТЧЁТ
    # ══════════════════════════════════════════════════
    async def send_daily_report(self, portfolio: dict, metrics: dict,
                                 signals: List[dict], trades_today: List[dict]):
        total    = metrics.get("total_amount", 0)
        daily_pl = metrics.get("daily_pl", 0)
        daily_pct= metrics.get("daily_pct", 0)
        ytd_pct  = metrics.get("ytd_pct", 0)
        alpha    = metrics.get("alpha", 0)
        drawdown = metrics.get("drawdown", 0)

        sign = "+" if daily_pl >= 0 else ""
        arrow = "📈" if daily_pct >= 0 else "📉"

        positions = portfolio.get("positions", [])

        text = (
            f"📊 <b>ЕЖЕДНЕВНЫЙ ОТЧЁТ</b>\n"
            f"{datetime.now().strftime('%d %B %Y, %A')}\n"
            f"{'═' * 30}\n"
            f"\n"
            f"💼 <b>ПОРТФЕЛЬ</b>\n"
            f"{'─' * 28}\n"
            f"💰 Стоимость:  <code>{total:>14,.0f} ₽</code>\n"
            f"{arrow} За день:     <code>{sign}{daily_pl:>12,.0f} ₽  ({sign}{daily_pct:.2f}%)</code>\n"
            f"📈 YTD:        <code>{'+' if ytd_pct>=0 else ''}{ytd_pct:>14.1f}%</code>\n"
            f"🎯 Альфа ММВБ: <code>{'+' if alpha>=0 else ''}{alpha:>14.1f}%</code>\n"
            f"📉 Просадка:   <code>{drawdown:>13.1f}%</code>\n"
            f"\n"
        )

        # Топ-3 позиции
        if positions:
            text += f"🏆 <b>ЛУЧШИЕ ПОЗИЦИИ</b>\n{'─' * 28}\n"
            sorted_pos = sorted(positions,
                                key=lambda p: p.get("pl_pct", 0), reverse=True)
            for pos in sorted_pos[:3]:
                pl   = pos.get("pl_pct", 0)
                sign2 = "+" if pl >= 0 else ""
                emoji2 = "🟢" if pl >= 0 else "🔴"
                text += f"{emoji2} {pos.get('ticker','?'):6s}  {sign2}{pl:.1f}%\n"
            text += "\n"

        # Сделки за день
        if trades_today:
            text += f"💼 <b>СДЕЛКИ ЗА ДЕНЬ: {len(trades_today)}</b>\n{'─' * 28}\n"
            for t in trades_today[:5]:
                emoji3 = "🟢" if t["action"] == "buy" else "🔴"
                text += f"{emoji3} {t['ticker']:6s} {t['action']:4s} {t['lots']}л @ {t['price']:,.0f}₽\n"
            text += "\n"

        # Топ сигналы на завтра
        if signals:
            text += f"🔭 <b>СИГНАЛЫ НА ЗАВТРА</b>\n{'─' * 28}\n"
            for sig in signals[:4]:
                bar = self._score_bar(sig["score"])
                text += f"• {sig['ticker']:6s} {bar} <code>{sig['score']:.2f}</code>  {sig.get('momentum_3m',0):+.1f}%\n"
            text += "\n"

        text += f"{'─' * 28}\n⏱ <code>{datetime.now().strftime('%H:%M')}</code>  Система работает ✅"

        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("💼 Детали", callback_data="portfolio"),
            InlineKeyboardButton("🔍 Сигналы", callback_data="signals"),
        ]]) if TELEGRAM_AVAILABLE else None
        await self._send(text, kb)

    # ══════════════════════════════════════════════════
    #  УТРЕННИЙ БРИФИНГ
    # ══════════════════════════════════════════════════
    async def send_morning_brief(self, signals: List[dict], portfolio: dict):
        total = portfolio.get("total_amount", 0)
        n_pos = len(portfolio.get("positions", []))

        text = (
            f"☀️ <b>УТРЕННИЙ БРИФИНГ</b>\n"
            f"{datetime.now().strftime('%d %B, %A')}\n"
            f"{'═' * 30}\n"
            f"\n"
            f"💼 Позиций: <code>{n_pos}</code>  |  Капитал: <code>{total:,.0f} ₽</code>\n"
            f"\n"
            f"🔭 <b>ТОП СИГНАЛЫ СЕГОДНЯ</b>\n{'─' * 28}\n"
        )
        for sig in signals[:5]:
            bar = self._score_bar(sig["score"])
            trend = "▲" if sig.get("momentum_3m", 0) > 0 else "▼"
            text += (
                f"• {sig['ticker']:6s} {bar} <code>{sig['score']:.2f}</code>  "
                f"{trend} {sig.get('momentum_3m',0):+.1f}%\n"
            )

        text += (
            f"\n{'─' * 28}\n"
            f"🤖 Система работает. Буду уведомлять о сделках."
        )
        await self._send(text)

    # ══════════════════════════════════════════════════
    #  РЕБАЛАНСИРОВКА
    # ══════════════════════════════════════════════════
    async def send_rebalance_report(self, buys: List[dict], sells: List[dict],
                                     new_portfolio: List[dict]):
        n_buy  = len(buys)
        n_sell = len(sells)
        n_hold = len(new_portfolio) - n_buy

        text = (
            f"⚖️ <b>РЕБАЛАНСИРОВКА</b>\n"
            f"{'─' * 28}\n"
            f"🟢 Куплено:  {n_buy} позиций\n"
            f"🔴 Продано:  {n_sell} позиций\n"
            f"⬤ Удержано: {n_hold} позиций\n"
            f"\n"
        )
        if buys:
            text += "<b>Покупки:</b>\n"
            for b in buys[:6]:
                text += f"  🟢 {b['ticker']:6s}  {b['weight']*100:.1f}%  <code>{b.get('target_rub',0):,.0f} ₽</code>\n"
        if sells:
            text += "<b>Продажи:</b>\n"
            for s in sells[:6]:
                text += f"  🔴 {s['ticker']:6s}  причина: {s.get('reason','—')}\n"

        text += f"\n{'─' * 28}\n⏱ <code>{datetime.now().strftime('%H:%M')}</code>"
        await self._send(text)

    # ══════════════════════════════════════════════════
    #  АЛЕРТЫ
    # ══════════════════════════════════════════════════
    async def send_risk_alert(self, alert_type: str, value: float, limit: float):
        emoji_map = {"drawdown": "📉", "var": "⚠️", "daily_loss": "🚨"}
        emoji = emoji_map.get(alert_type, "⚠️")
        names = {"drawdown": "Просадка", "var": "VaR", "daily_loss": "Дневной убыток"}
        name  = names.get(alert_type, alert_type)
        text = (
            f"{emoji} <b>РИСК-АЛЕРТ: {name}</b>\n"
            f"{'─' * 28}\n"
            f"Текущее: <code>{value:.1f}%</code>\n"
            f"Лимит:   <code>{limit:.1f}%</code>\n"
            f"{'─' * 28}\n"
            f"Система автоматически снижает позиции.\n"
            f"⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        )
        await self._send(text)

    async def send_error(self, error: str):
        text = (
            f"🔧 <b>Ошибка системы</b>\n"
            f"{'─' * 28}\n"
            f"<code>{error[:300]}</code>\n"
            f"{'─' * 28}\n"
            f"Система продолжает работу.\n"
            f"⏱ <code>{datetime.now().strftime('%H:%M:%S')}</code>"
        )
        await self._send(text)

    # ══════════════════════════════════════════════════
    #  ХЕЛПЕРЫ
    # ══════════════════════════════════════════════════
    @staticmethod
    def _score_bar(score: float) -> str:
        """Визуальный бар скора из 5 символов."""
        filled = round(score * 5)
        return "█" * filled + "░" * (5 - filled)

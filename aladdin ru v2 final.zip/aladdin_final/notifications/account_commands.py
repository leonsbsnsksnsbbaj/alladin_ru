# notifications/account_commands.py
"""
Команды для управления счётами и sandbox.

/accounts          — список всех счетов
/switch_account    — переключить счёт (через кнопки)
/topup 500000      — пополнить sandbox на 500к ₽
/account_info      — инфо о текущем счёте
"""

import logging
from datetime import datetime

log = logging.getLogger("aladdin.account_cmd")

try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import CommandHandler, CallbackQueryHandler, ContextTypes
    from telegram.constants import ParseMode
    TG_OK = True
except ImportError:
    TG_OK = False


class AccountCommands:
    def __init__(self, cfg, state, broker, tg):
        self.cfg    = cfg
        self.state  = state
        self.broker = broker
        self.tg     = tg

    def register(self, app):
        app.add_handler(CommandHandler("accounts",     self._cmd_accounts))
        app.add_handler(CommandHandler("account_info", self._cmd_account_info))
        app.add_handler(CommandHandler("topup",        self._cmd_topup))
        app.add_handler(CallbackQueryHandler(self._on_button, pattern="^acc_"))

    def _auth(self, update):
        return str(update.effective_chat.id) == str(self.cfg.TELEGRAM_CHAT_ID)

    # ══════════════════════════════════════════════════════
    #  /accounts — показать все счета
    # ══════════════════════════════════════════════════════
    async def _cmd_accounts(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return

        await update.message.reply_text("⏳ Загружаю список счетов...")
        accounts = await self.broker.get_accounts_list()
        current  = self.broker.get_current_account_info()
        current_id = self.broker._account_id

        if not accounts:
            await update.message.reply_text(
                "❌ Не удалось получить список счетов.\n"
                "Проверь токен в .env"
            )
            return

        # Строим кнопки — одна кнопка на счёт
        buttons = []
        for acc in accounts:
            is_current = (acc["id"] == current_id)
            label = f"{'✅ ' if is_current else ''}{acc['type']}  {acc['name']}"
            buttons.append([InlineKeyboardButton(
                label,
                callback_data=f"acc_switch_{acc['id']}"
            )])

        kb = InlineKeyboardMarkup(buttons)

        text = (
            f"🏦 <b>Счета Т-Банк</b>\n"
            f"{'─'*28}\n"
        )
        for acc in accounts:
            is_current = (acc["id"] == current_id)
            check = "✅" if is_current else "  "
            text += (
                f"{check} <b>{acc['type']}</b>  {acc['name']}\n"
                f"    <code>{acc['id'][:16]}...</code>\n"
            )

        if self.cfg.SANDBOX:
            text += (
                f"\n{'─'*28}\n"
                f"🟡 <b>Режим Sandbox</b>\n"
                f"Виртуальные деньги, реальные цены.\n"
                f"Пополнить: <code>/topup 1000000</code>"
            )
        else:
            text += f"\n🔴 <b>Боевой режим</b> — реальные деньги!"

        text += f"\n\n<i>Нажми на счёт чтобы переключиться:</i>"

        await update.message.reply_text(
            text, parse_mode=ParseMode.HTML, reply_markup=kb
        )

    # ══════════════════════════════════════════════════════
    #  /account_info — инфо о текущем счёте
    # ══════════════════════════════════════════════════════
    async def _cmd_account_info(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return

        info      = self.broker.get_current_account_info()
        portfolio = await self.broker.get_portfolio()
        total     = portfolio.get("total_amount", 0)
        cash      = portfolio.get("cash_rub", 0)
        positions = len(portfolio.get("positions", []))

        mode_text = (
            "🟡 <b>SANDBOX</b> — тестовый режим\nДеньги виртуальные, цены реальные"
            if self.cfg.SANDBOX
            else "🔴 <b>БОЕВОЙ</b> — реальные деньги"
        )

        text = (
            f"🏦 <b>Текущий счёт</b>\n"
            f"{'─'*28}\n"
        )
        if info:
            text += (
                f"Название:  <b>{info['name']}</b>\n"
                f"Тип:       {info['type']}\n"
                f"ID:        <code>{info['id']}</code>\n"
                f"{'─'*28}\n"
            )
        text += (
            f"Режим:     {mode_text}\n"
            f"{'─'*28}\n"
            f"💼 Капитал:   <code>{total:>12,.0f} ₽</code>\n"
            f"💵 Свободно:  <code>{cash:>12,.0f} ₽</code>\n"
            f"📦 Позиций:   <code>{positions:>12}</code>\n"
        )

        if self.cfg.SANDBOX:
            text += (
                f"\n💡 Пополнить sandbox:\n"
                f"<code>/topup 1000000</code>"
            )

        await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    # ══════════════════════════════════════════════════════
    #  /topup 1000000 — пополнить sandbox
    # ══════════════════════════════════════════════════════
    async def _cmd_topup(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return

        if not self.cfg.SANDBOX:
            await update.message.reply_text(
                "⛔ /topup работает только в режиме Sandbox.\n"
                "Сейчас у тебя боевой режим (SANDBOX=false)."
            )
            return

        args = ctx.args
        try:
            amount = float(args[0].replace(" ","")) if args else 1_000_000
        except (ValueError, IndexError):
            amount = 1_000_000

        await update.message.reply_text(
            f"⏳ Пополняю sandbox на {amount:,.0f} ₽..."
        )

        ok = await self.broker.sandbox_top_up(amount)
        if ok:
            portfolio = await self.broker.get_portfolio()
            total     = portfolio.get("total_amount", 0)
            await update.message.reply_text(
                f"✅ <b>Sandbox пополнен!</b>\n"
                f"{'─'*28}\n"
                f"➕ Добавлено:  <code>+{amount:,.0f} ₽</code>\n"
                f"💼 Итого:      <code>{total:,.0f} ₽</code>\n\n"
                f"Теперь можно тестировать торговлю.\n"
                f"Запусти скан: /scan",
                parse_mode=ParseMode.HTML
            )
        else:
            await update.message.reply_text(
                "❌ Ошибка пополнения. Проверь логи: /logs"
            )

    # ══════════════════════════════════════════════════════
    #  КНОПКИ: переключение счёта
    # ══════════════════════════════════════════════════════
    async def _on_button(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()

        if query.data.startswith("acc_switch_"):
            account_id = query.data[len("acc_switch_"):]
            result = await self.broker.switch_account(account_id)

            if "error" in result:
                await query.edit_message_text(f"❌ {result['error']}")
            else:
                # Останавливаем торговлю на время переключения
                self.state.is_running = False
                await query.edit_message_text(
                    f"✅ <b>Счёт переключён</b>\n\n"
                    f"Тип:  {result['type']}\n"
                    f"Имя:  {result['name']}\n"
                    f"ID:   <code>{result['id']}</code>\n\n"
                    f"⏸ Торговля поставлена на паузу.\n"
                    f"Возобнови когда будешь готов: /resume",
                    parse_mode=ParseMode.HTML
                )

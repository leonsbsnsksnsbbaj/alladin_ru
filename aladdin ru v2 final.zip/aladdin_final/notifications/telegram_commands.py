# notifications/telegram_commands.py
"""
Полное управление ботом через Telegram-команды.
Телефон = единственный инструмент управления.
"""

import asyncio
import logging
from datetime import datetime
from typing import TYPE_CHECKING

log = logging.getLogger("aladdin.tg_commands")

try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        ApplicationBuilder, CommandHandler, CallbackQueryHandler,
        ContextTypes, Application,
    )
    from telegram.constants import ParseMode
    TG_OK = True
except ImportError:
    TG_OK = False


class TelegramCommands:
    """
    Запускает polling-бот который принимает команды с телефона.
    Все команды управляют живым scheduler через shared state.
    """

    def __init__(self, cfg, state, scheduler, tg_notifier, news_engine):
        self.cfg        = cfg
        self.state      = state
        self.scheduler  = scheduler
        self.tg         = tg_notifier
        self.news       = news_engine
        self._app: Application = None

    async def start(self):
        if not TG_OK:
            log.warning("python-telegram-bot не установлен")
            return

        self._app = (
            ApplicationBuilder()
            .token(self.cfg.TELEGRAM_BOT_TOKEN)
            .build()
        )

        # Регистрируем команды
        handlers = [
            ("start",     self._cmd_start),
            ("help",      self._cmd_help),
            ("status",    self._cmd_status),
            ("portfolio", self._cmd_portfolio),
            ("signals",   self._cmd_signals),
            ("news",      self._cmd_news),
            ("pause",     self._cmd_pause),
            ("resume",    self._cmd_resume),
            ("rebalance", self._cmd_rebalance),
            ("scan",      self._cmd_scan),
            ("risk",      self._cmd_risk),
            ("report",    self._cmd_report),
            ("ticker",    self._cmd_ticker),
            ("settings",  self._cmd_settings),
        ]
        for name, handler in handlers:
            self._app.add_handler(CommandHandler(name, handler))

        # Inline кнопки
        self._app.add_handler(CallbackQueryHandler(self._on_button))

        # Запускаем в фоне
        await self._app.initialize()
        await self._app.start()
        await self._app.updater.start_polling(drop_pending_updates=True)
        log.info("Telegram командный бот запущен")

    async def stop(self):
        if self._app:
            await self._app.updater.stop()
            await self._app.stop()

    # ── Проверка доступа (только твой chat_id) ───────────
    def _auth(self, update: Update) -> bool:
        return str(update.effective_chat.id) == str(self.cfg.TELEGRAM_CHAT_ID)

    def _deny(self):
        return "⛔ Нет доступа"

    # ══════════════════════════════════════════════════════
    #  /start и /help
    # ══════════════════════════════════════════════════════
    async def _cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Статус",    callback_data="status"),
             InlineKeyboardButton("💼 Портфель",  callback_data="portfolio")],
            [InlineKeyboardButton("🔍 Сигналы",   callback_data="signals"),
             InlineKeyboardButton("📰 Новости",   callback_data="news")],
            [InlineKeyboardButton("⏸ Пауза",      callback_data="pause"),
             InlineKeyboardButton("▶️ Запустить", callback_data="resume")],
            [InlineKeyboardButton("⚖️ Ребаланс",  callback_data="rebalance"),
             InlineKeyboardButton("🛡 Риски",     callback_data="risk")],
        ])
        await update.message.reply_text(
            "⬡ <b>ALADDIN RU</b> — управление\n\n"
            "Нажми кнопку или введи команду:",
            parse_mode=ParseMode.HTML,
            reply_markup=kb,
        )

    async def _cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        text = (
            "⬡ <b>Команды ALADDIN RU</b>\n"
            "─────────────────────────\n"
            "/status     — состояние системы\n"
            "/portfolio  — текущий портфель\n"
            "/signals    — топ сигналы сканера\n"
            "/news       — свежие новости\n"
            "/risk       — риск-метрики\n"
            "/report     — дневной отчёт сейчас\n"
            "/pause      — поставить на паузу\n"
            "/resume     — возобновить торговлю\n"
            "/rebalance  — ребалансировать сейчас\n"
            "/scan       — просканировать рынок\n"
            "/ticker SBER — инфо по тикеру\n"
            "/settings   — текущие настройки\n"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    # ══════════════════════════════════════════════════════
    #  /status
    # ══════════════════════════════════════════════════════
    async def _cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        s = self.state
        mode    = "🟡 ПЕСОЧНИЦА" if self.cfg.SANDBOX else "🔴 БОЕВОЙ"
        running = "▶️ РАБОТАЕТ" if s.is_running else "⏸ ПАУЗА"

        text = (
            f"⬡ <b>Статус системы</b>\n"
            f"─────────────────────────\n"
            f"Режим:     {mode}\n"
            f"Состояние: {running}\n"
            f"Цикл:      #{s.cycle_count:,}\n"
            f"Время:     <code>{datetime.now().strftime('%H:%M:%S')}</code>\n"
            f"─────────────────────────\n"
            f"Вселенная: {len(s.universe)} инструментов\n"
            f"Сигналов:  {len(s.signals)} выше порога\n"
            f"Позиций:   {len(s.portfolio)}\n"
            f"─────────────────────────\n"
            f"Капитал:   <code>{s.peak_value:,.0f} ₽</code>\n"
        )
        kb = self._main_kb()
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await update.message.reply_text(
                text, parse_mode=ParseMode.HTML, reply_markup=kb)

    # ══════════════════════════════════════════════════════
    #  /portfolio
    # ══════════════════════════════════════════════════════
    async def _cmd_portfolio(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        port = self.state.portfolio
        if not port:
            text = "💼 Портфель пуст или ещё не загружен.\nПопробуй /scan"
        else:
            lines = ["💼 <b>Текущий портфель</b>", "─────────────────────────"]
            stocks = [p for p in port if p.get("type") == "stock"]
            bonds  = [p for p in port if p.get("type") == "bond"]
            total_w = sum(p.get("weight", 0) for p in port)

            for p in sorted(port, key=lambda x: x.get("weight", 0), reverse=True):
                emoji = "📈" if p.get("type") == "stock" else "📊"
                score_bar = "█" * round(p.get("score", 0) * 5) + \
                            "░" * (5 - round(p.get("score", 0) * 5))
                lines.append(
                    f"{emoji} <b>{p['ticker']}</b>  "
                    f"{p.get('weight', 0)*100:.1f}%  "
                    f"{score_bar}"
                )
            lines.append("─────────────────────────")
            lines.append(f"Акций: {len(stocks)}  Облиг: {len(bonds)}")
            lines.append(f"Итого вес: {total_w*100:.0f}%")
            text = "\n".join(lines)

        kb = self._main_kb()
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await update.message.reply_text(
                text, parse_mode=ParseMode.HTML, reply_markup=kb)

    # ══════════════════════════════════════════════════════
    #  /signals
    # ══════════════════════════════════════════════════════
    async def _cmd_signals(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        sigs = self.state.signals[:8]
        if not sigs:
            text = "🔍 Сигналов нет. Запусти /scan"
        else:
            lines = [
                f"🔍 <b>Топ сигналы</b>  "
                f"<code>{datetime.now().strftime('%H:%M')}</code>",
                "─────────────────────────",
            ]
            for i, s in enumerate(sigs, 1):
                bar   = "█" * round(s["score"] * 5) + "░" * (5 - round(s["score"] * 5))
                mom   = s.get("momentum_3m", 0)
                msign = "▲" if mom > 0 else "▼"
                lines.append(
                    f"{i}. <b>{s['ticker']}</b> {bar} <code>{s['score']:.2f}</code>  "
                    f"{msign}{abs(mom):.1f}%"
                )
            text = "\n".join(lines)

        kb = self._main_kb()
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await update.message.reply_text(
                text, parse_mode=ParseMode.HTML, reply_markup=kb)

    # ══════════════════════════════════════════════════════
    #  /news
    # ══════════════════════════════════════════════════════
    async def _cmd_news(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        scores = self.news.get_all_scores() if self.news else {}

        if not scores:
            text = "📰 Новостей ещё нет. Система собирает данные..."
        else:
            lines = ["📰 <b>Новостной фон</b>", "─────────────────────────"]
            # Сортируем по отклонению от нейтрали
            sorted_scores = sorted(
                scores.items(),
                key=lambda x: abs(x[1]["score"] - 0.5),
                reverse=True
            )
            for ticker, data in sorted_scores[:8]:
                sc = data["score"]
                if sc > 0.6:   emoji = "🟢"
                elif sc < 0.4: emoji = "🔴"
                else:          emoji = "⬤"
                bar = "█" * round(sc * 5) + "░" * (5 - round(sc * 5))
                # Последняя новость
                last_news = data.get("news", [{}])[-1]
                gpt_icon  = "🤖" if last_news.get("gpt") else ""
                summary   = last_news.get("summary") or last_news.get("title", "")[:50]
                lines.append(
                    f"{emoji} <b>{ticker}</b> {bar}\n"
                    f"   {gpt_icon}{summary[:60]}"
                )
            text = "\n".join(lines)

        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, parse_mode=ParseMode.HTML, reply_markup=self._main_kb())
        else:
            await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    # ══════════════════════════════════════════════════════
    #  /ticker SBER
    # ══════════════════════════════════════════════════════
    async def _cmd_ticker(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        args = ctx.args
        if not args:
            await update.message.reply_text("Укажи тикер: /ticker SBER")
            return
        ticker = args[0].upper()

        # Ищем в сигналах
        info = next((s for s in self.state.signals if s.get("ticker") == ticker), None)
        news_data = self.news.get_ticker_news(ticker) if self.news else []

        if not info:
            text = f"❓ <b>{ticker}</b> не найден в последнем скане.\n"
        else:
            bar = "█" * round(info["score"] * 5) + "░" * (5 - round(info["score"] * 5))
            text = (
                f"📋 <b>{ticker}</b> — {info.get('name','')}\n"
                f"─────────────────────────\n"
                f"Скор:      {bar} <code>{info['score']:.2f}</code>\n"
                f"RSI:       <code>{info.get('rsi', 50):.0f}</code>\n"
                f"Моментум:  <code>{info.get('momentum_3m', 0):+.1f}%</code> (3м)\n"
                f"Объём:     <code>{info.get('volume_spike', 1):.1f}x</code>\n"
                f"Новости:   <code>{info.get('news_score', 0.5):.2f}</code>\n"
            )

        if news_data:
            text += "─────────────────────────\n📰 <b>Последние новости:</b>\n"
            for n in news_data[-3:]:
                sc = n.get("sentiment", 0.5)
                em = "🟢" if sc > 0.6 else "🔴" if sc < 0.4 else "⬤"
                gpt = "🤖" if n.get("gpt") else ""
                summary = n.get("summary") or n.get("title", "")
                text += f"{em}{gpt} {summary[:70]}\n"

        await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    # ══════════════════════════════════════════════════════
    #  /risk
    # ══════════════════════════════════════════════════════
    async def _cmd_risk(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        s   = self.state
        dd  = 0.0
        if s.peak_value > 0 and s.day_start_value > 0:
            dd = max(0, (s.peak_value - s.day_start_value) / s.peak_value * 100)

        dd_bar   = "█" * min(10, int(dd / self.cfg.MAX_DRAWDOWN / 100 * 10))
        dd_bar  += "░" * (10 - len(dd_bar))
        dd_emoji = "🟢" if dd < 5 else "🟡" if dd < 10 else "🔴"

        text = (
            f"🛡 <b>Риск-метрики</b>\n"
            f"─────────────────────────\n"
            f"{dd_emoji} Просадка:  <code>{dd:.1f}%</code>  лимит {self.cfg.MAX_DRAWDOWN*100:.0f}%\n"
            f"   {dd_bar}\n"
            f"📉 Стоп-лосс:    {self.cfg.STOP_LOSS_PCT*100:.0f}% по позиции\n"
            f"📈 Тейк-профит:  {self.cfg.TAKE_PROFIT_PCT*100:.0f}% по позиции\n"
            f"💼 Макс. позиция: {self.cfg.MAX_POSITION_PCT*100:.0f}%\n"
            f"🏦 Резерв кэша:  {self.cfg.CASH_RESERVE*100:.0f}%\n"
            f"─────────────────────────\n"
            f"Система {'✅ активна' if s.is_running else '⏸ на паузе'}"
        )
        kb = self._main_kb()
        if update.callback_query:
            await update.callback_query.edit_message_text(
                text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    # ══════════════════════════════════════════════════════
    #  УПРАВЛЕНИЕ СИСТЕМОЙ
    # ══════════════════════════════════════════════════════
    async def _cmd_pause(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        self.state.is_running = False
        text = "⏸ <b>Система поставлена на паузу.</b>\nТорговля остановлена.\n/resume чтобы возобновить."
        if update.callback_query:
            await update.callback_query.answer("Поставлено на паузу")
            await update.callback_query.edit_message_text(
                text, parse_mode=ParseMode.HTML, reply_markup=self._main_kb())
        else:
            await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    async def _cmd_resume(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        self.state.is_running = True
        text = "▶️ <b>Система возобновлена.</b>\nТорговля активна."
        if update.callback_query:
            await update.callback_query.answer("Возобновлено")
            await update.callback_query.edit_message_text(
                text, parse_mode=ParseMode.HTML, reply_markup=self._main_kb())
        else:
            await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    async def _cmd_rebalance(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        msg = "⚖️ Ребалансировка запущена... Жди уведомления о сделках."
        if update.callback_query:
            await update.callback_query.answer("Запущено")
            await update.callback_query.edit_message_text(msg, reply_markup=self._main_kb())
        else:
            await update.message.reply_text(msg)
        # Сбрасываем флаг чтобы scheduler запустил ребалансировку
        self.state.last_rebalance_day = ""

    async def _cmd_scan(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        msg = "🔍 Сканирование запущено... Займёт 1-2 минуты."
        if update.callback_query:
            await update.callback_query.answer("Сканирование...")
            await update.callback_query.edit_message_text(msg, reply_markup=self._main_kb())
        else:
            await update.message.reply_text(msg)
        # Запускаем сканирование
        asyncio.ensure_future(self.scheduler._run_scan())

    async def _cmd_report(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        await update.message.reply_text("📊 Формирую отчёт...")
        # Принудительный дневной отчёт
        self.state.last_rebalance_day = ""
        asyncio.ensure_future(
            self.scheduler._maybe_daily_report(datetime.now())
        )

    async def _cmd_settings(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self._auth(update): return
        cfg = self.cfg
        text = (
            f"⚙️ <b>Настройки</b>\n"
            f"─────────────────────────\n"
            f"Режим: {'🟡 Песочница' if cfg.SANDBOX else '🔴 Боевой'}\n"
            f"Макс. позиций: {cfg.MAX_POSITIONS}\n"
            f"Макс. вес позиции: {cfg.MAX_POSITION_PCT*100:.0f}%\n"
            f"Акции / Облиги: {cfg.STOCKS_ALLOCATION*100:.0f}% / {cfg.BONDS_ALLOCATION*100:.0f}%\n"
            f"Стоп-лосс: {cfg.STOP_LOSS_PCT*100:.0f}%\n"
            f"Тейк-профит: {cfg.TAKE_PROFIT_PCT*100:.0f}%\n"
            f"Макс. просадка: {cfg.MAX_DRAWDOWN*100:.0f}%\n"
            f"Ребалансировка: каждые {cfg.REBALANCE_INTERVAL//3600}ч\n"
            f"─────────────────────────\n"
            f"YandexGPT: {'✅ подключён' if cfg.YAGPT_TOKEN else '❌ не задан'}\n"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.HTML)

    # ══════════════════════════════════════════════════════
    #  INLINE КНОПКИ
    # ══════════════════════════════════════════════════════
    async def _on_button(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data
        # Перенаправляем на команды
        handlers = {
            "status":    self._cmd_status,
            "portfolio": self._cmd_portfolio,
            "signals":   self._cmd_signals,
            "news":      self._cmd_news,
            "pause":     self._cmd_pause,
            "resume":    self._cmd_resume,
            "rebalance": self._cmd_rebalance,
            "risk":      self._cmd_risk,
        }
        if data in handlers:
            await handlers[data](update, ctx)

    def _main_kb(self):
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 Статус",   callback_data="status"),
             InlineKeyboardButton("💼 Портфель", callback_data="portfolio")],
            [InlineKeyboardButton("🔍 Сигналы",  callback_data="signals"),
             InlineKeyboardButton("📰 Новости",  callback_data="news")],
        ])

# news/yandex_gpt_news.py
"""
Новостной движок на YandexGPT.
Читает Яндекс Новости RSS → анализирует через YandexGPT → даёт точный сентимент.
Русскоязычные финансовые новости понимает лучше любой западной модели.
"""

import asyncio
import logging
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from dataclasses import dataclass, field
import json
import re

log = logging.getLogger("aladdin.news")

try:
    import aiohttp
    AIOHTTP_OK = True
except ImportError:
    AIOHTTP_OK = False
    log.warning("aiohttp не установлен: pip install aiohttp")


# ── RSS ленты Яндекс Новостей ─────────────────────────────
YANDEX_RSS_FEEDS = [
    "https://news.yandex.ru/business.rss",
    "https://news.yandex.ru/economics.rss",
    "https://news.yandex.ru/finances.rss",
]

# Дополнительные RSS источники (бесплатно)
EXTRA_RSS_FEEDS = [
    "https://www.rbc.ru/finances/rss/",
    "https://www.interfax.ru/rss/finance.asp",
    "https://tass.ru/rss/v2.xml",
]


@dataclass
class NewsItem:
    title:     str
    body:      str = ""
    source:    str = ""
    url:       str = ""
    pub_time:  Optional[datetime] = None
    tickers:   List[str] = field(default_factory=list)
    sentiment: float = 0.5        # 0=негатив, 0.5=нейтрал, 1=позитив
    impact:    str = "low"        # low / medium / high
    summary:   str = ""           # краткое резюме от GPT
    gpt_used:  bool = False


class YandexGPTNewsEngine:
    def __init__(self, cfg):
        self.cfg = cfg
        self.yagpt_token    = getattr(cfg, "YAGPT_TOKEN", "")
        self.yagpt_folder   = getattr(cfg, "YAGPT_FOLDER_ID", "")
        self._cache: Dict[str, NewsItem] = {}        # url → NewsItem
        self._scores: Dict[str, dict]   = {}         # ticker → {score, updated}

    # ══════════════════════════════════════════════════════
    #  ГЛАВНАЯ ФУНКЦИЯ
    # ══════════════════════════════════════════════════════
    async def fetch_and_analyze(self, universe: List[dict]) -> Dict[str, float]:
        """
        Возвращает словарь {ticker: news_score} для всех инструментов.
        Вызывается из scheduler каждые 3 минуты.
        """
        # 1. Получить свежие новости
        raw_news = await self._fetch_all_rss()
        log.info(f"Новостей получено: {len(raw_news)}")

        if not raw_news:
            return self._get_cached_scores()

        # 2. Построить карту тикеров для поиска упоминаний
        ticker_map = self._build_ticker_map(universe)

        # 3. Привязать новости к тикерам
        for item in raw_news:
            item.tickers = self._find_tickers(item.title + " " + item.body, ticker_map)

        # Оставляем только новости с упоминанием конкретных компаний
        relevant = [n for n in raw_news if n.tickers]
        log.info(f"Новостей с тикерами: {len(relevant)}")

        # 4. Анализ через YandexGPT (батчами по 5)
        if self.yagpt_token and relevant:
            await self._analyze_batch_gpt(relevant[:20])  # макс 20 за цикл
        else:
            # Fallback: ключевые слова
            for item in relevant:
                item.sentiment = self._keyword_sentiment(item.title + " " + item.body)
                item.gpt_used  = False

        # 5. Обновить скоры тикеров
        self._update_scores(relevant)

        return self._get_cached_scores()

    # ══════════════════════════════════════════════════════
    #  RSS ПАРСИНГ
    # ══════════════════════════════════════════════════════
    async def _fetch_all_rss(self) -> List[NewsItem]:
        if not AIOHTTP_OK:
            return []

        all_news = []
        feeds = YANDEX_RSS_FEEDS + EXTRA_RSS_FEEDS
        cutoff = datetime.now() - timedelta(hours=6)  # только свежие

        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=10),
            headers={"User-Agent": "Mozilla/5.0 ALADDIN-RU/1.0"}
        ) as session:
            tasks = [self._fetch_rss(session, url) for url in feeds]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for items in results:
                if isinstance(items, list):
                    for item in items:
                        # Пропускаем уже обработанные и старые
                        if item.url not in self._cache:
                            if not item.pub_time or item.pub_time > cutoff:
                                all_news.append(item)

        return all_news

    async def _fetch_rss(self, session, url: str) -> List[NewsItem]:
        try:
            async with session.get(url) as resp:
                if resp.status != 200:
                    return []
                text = await resp.text(errors="replace")
            return self._parse_rss(text, url)
        except Exception as e:
            log.debug(f"RSS {url}: {e}")
            return []

    def _parse_rss(self, xml_text: str, source_url: str) -> List[NewsItem]:
        items = []
        try:
            root = ET.fromstring(xml_text)
            ns = {"yandex": "http://news.yandex.ru"}

            for entry in root.iter("item"):
                title = entry.findtext("title", "").strip()
                desc  = entry.findtext("description", "").strip()
                link  = entry.findtext("link", "").strip()
                pub   = entry.findtext("pubDate", "")

                # Парсим дату
                pub_time = None
                try:
                    from email.utils import parsedate_to_datetime
                    pub_time = parsedate_to_datetime(pub).replace(tzinfo=None)
                except Exception:
                    pass

                # Определяем источник
                source = "Яндекс.Новости"
                if "rbc.ru" in source_url:     source = "РБК"
                elif "interfax" in source_url: source = "Интерфакс"
                elif "tass.ru" in source_url:  source = "ТАСС"

                if title:
                    items.append(NewsItem(
                        title=title, body=desc,
                        source=source, url=link,
                        pub_time=pub_time,
                    ))
        except ET.ParseError as e:
            log.debug(f"XML ошибка: {e}")
        return items

    # ══════════════════════════════════════════════════════
    #  ПОИСК ТИКЕРОВ В ТЕКСТЕ
    # ══════════════════════════════════════════════════════
    def _build_ticker_map(self, universe: List[dict]) -> Dict[str, List[str]]:
        """
        Возвращает словарь: ключевое слово → список тикеров.
        Например: "сбербанк" → ["SBER"], "лукойл" → ["LKOH"]
        """
        mapping = {}
        for instr in universe:
            ticker = instr.get("ticker", "")
            name   = instr.get("name", "")
            if not ticker:
                continue
            # Тикер напрямую
            mapping[ticker.upper()] = [ticker]
            # Первые слова названия (длиннее 4 букв)
            for word in name.split():
                w = word.lower().strip(".,«»\"'")
                if len(w) > 4:
                    mapping.setdefault(w, []).append(ticker)

        # Ручная карта самых известных
        MANUAL = {
            "сбербанк": "SBER", "сбер": "SBER",
            "лукойл": "LKOH",
            "газпром": "GAZP",
            "роснефть": "ROSN",
            "новатэк": "NVTK",
            "норникель": "GMKN", "норильский": "GMKN",
            "татнефть": "TATN",
            "северсталь": "CHMF",
            "ммк": "MAGN",
            "нлмк": "NLMK",
            "аэрофлот": "AFLT",
            "полюс": "PLZL",
            "алроса": "ALRS",
            "мтс": "MTSS",
            "интеррао": "IRAO", "интер рао": "IRAO",
            "фосагро": "PHOR",
            "яндекс": "YDEX",
            "вк": "VKCO", "вконтакте": "VKCO",
            "тинькофф": "TCSG", "т-банк": "TCSG",
            "магнит": "MGNT",
            "х5": "X5", "пятёрочка": "X5",
        }
        for word, ticker in MANUAL.items():
            mapping[word] = [ticker]

        return mapping

    def _find_tickers(self, text: str, ticker_map: Dict) -> List[str]:
        text_lower = text.lower()
        found = set()
        for keyword, tickers in ticker_map.items():
            if keyword.lower() in text_lower:
                found.update(tickers)
        return list(found)

    # ══════════════════════════════════════════════════════
    #  YANDEXGPT АНАЛИЗ
    # ══════════════════════════════════════════════════════
    async def _analyze_batch_gpt(self, news_items: List[NewsItem]):
        """Анализирует новости через YandexGPT API."""
        if not AIOHTTP_OK:
            return

        url = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"
        headers = {
            "Authorization": f"Api-Key {self.yagpt_token}",
            "Content-Type": "application/json",
        }

        # Обрабатываем по одной (можно батчем но надёжнее по одной)
        async with aiohttp.ClientSession() as session:
            for item in news_items:
                try:
                    result = await self._gpt_analyze_one(session, url, headers, item)
                    if result:
                        item.sentiment = result.get("sentiment", 0.5)
                        item.impact    = result.get("impact", "low")
                        item.summary   = result.get("summary", "")
                        item.gpt_used  = True
                        log.debug(
                            f"GPT [{item.source}]: {item.title[:40]}... "
                            f"→ {item.sentiment:.2f} ({item.impact})"
                        )
                    await asyncio.sleep(0.3)  # rate limit
                except Exception as e:
                    log.debug(f"GPT ошибка: {e}")
                    # Fallback на ключевые слова
                    item.sentiment = self._keyword_sentiment(item.title)

    async def _gpt_analyze_one(self, session, url, headers, item: NewsItem) -> Optional[dict]:
        prompt = f"""Ты финансовый аналитик российского рынка акций.

Проанализируй эту новость и верни ТОЛЬКО JSON без пояснений:
{{
  "sentiment": <число от 0.0 до 1.0, где 0=очень негативно, 0.5=нейтрально, 1.0=очень позитивно>,
  "impact": "<low|medium|high — насколько сильно влияет на цену акции>",
  "summary": "<одно предложение: суть влияния на компанию по-русски>"
}}

Новость: {item.title}
{item.body[:300] if item.body else ''}

Компании в новости: {', '.join(item.tickers)}"""

        payload = {
            "modelUri": f"gpt://{self.yagpt_folder}/yandexgpt-lite/latest",
            "completionOptions": {
                "stream": False,
                "temperature": 0.1,
                "maxTokens": 150,
            },
            "messages": [
                {"role": "user", "text": prompt}
            ],
        }

        async with session.post(url, headers=headers, json=payload,
                                timeout=aiohttp.ClientTimeout(total=8)) as resp:
            if resp.status != 200:
                return None
            data = await resp.json()

        # Извлекаем текст ответа
        text = ""
        try:
            text = data["result"]["alternatives"][0]["message"]["text"]
            # Ищем JSON в ответе
            json_match = re.search(r'\{[^}]+\}', text, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
                # Нормализуем
                result["sentiment"] = float(
                    max(0.0, min(1.0, result.get("sentiment", 0.5)))
                )
                return result
        except Exception:
            pass
        return None

    # ══════════════════════════════════════════════════════
    #  FALLBACK: КЛЮЧЕВЫЕ СЛОВА
    # ══════════════════════════════════════════════════════
    POSITIVE = [
        "прибыль", "рост", "увеличение", "дивиденд", "buyback", "выкуп",
        "рекорд", "повышение", "сделка", "расширение", "партнёрство",
        "одобрен", "выплата", "превысил", "вырос", "улучшение", "договор",
        "инвестиции", "подъём", "успех", "прогноз повышен", "рейтинг повышен",
    ]
    NEGATIVE = [
        "убыток", "снижение", "санкции", "штраф", "иск", "дефолт",
        "банкротство", "сокращение", "отставка", "авария", "расследование",
        "проверка", "задержка", "отказ", "кризис", "упал", "ухудшение",
        "понижен", "риск", "долг", "потеря", "обвал", "заморозка",
    ]

    def _keyword_sentiment(self, text: str) -> float:
        t = text.lower()
        pos = sum(1 for w in self.POSITIVE if w in t)
        neg = sum(1 for w in self.NEGATIVE if w in t)
        total = pos + neg
        if total == 0:
            return 0.5
        raw = (pos - neg) / total
        return max(0.0, min(1.0, 0.5 + raw * 0.4))

    # ══════════════════════════════════════════════════════
    #  ОБНОВЛЕНИЕ СКОРОВ
    # ══════════════════════════════════════════════════════
    def _update_scores(self, news_items: List[NewsItem]):
        now = datetime.now().timestamp()
        DECAY = 0.85  # затухание за каждый цикл

        # Затухаем старые скоры
        for ticker in list(self._scores.keys()):
            age_hours = (now - self._scores[ticker]["updated"]) / 3600
            if age_hours > 48:
                del self._scores[ticker]
            else:
                self._scores[ticker]["score"] = (
                    0.5 + (self._scores[ticker]["score"] - 0.5) * DECAY
                )

        # Применяем новые новости
        IMPACT_WEIGHT = {"low": 0.08, "medium": 0.15, "high": 0.25}

        for item in news_items:
            weight = IMPACT_WEIGHT.get(item.impact, 0.08)
            for ticker in item.tickers:
                if ticker not in self._scores:
                    self._scores[ticker] = {"score": 0.5, "updated": now,
                                             "news": []}
                old = self._scores[ticker]["score"]
                # Тянем скор к новому сентименту с весом
                new_score = old + (item.sentiment - old) * weight
                self._scores[ticker]["score"]   = max(0.0, min(1.0, new_score))
                self._scores[ticker]["updated"] = now
                # Сохраняем последние 3 новости
                self._scores[ticker].setdefault("news", []).append({
                    "title": item.title[:80],
                    "sentiment": item.sentiment,
                    "impact": item.impact,
                    "source": item.source,
                    "gpt": item.gpt_used,
                    "summary": item.summary,
                })
                self._scores[ticker]["news"] = self._scores[ticker]["news"][-3:]

                log.info(
                    f"Новость [{item.source}{'🤖' if item.gpt_used else ''}]: "
                    f"{ticker}  {old:.2f}→{new_score:.2f}  "
                    f"«{item.title[:50]}»"
                )
            # Кэшируем
            self._cache[item.url] = item

    def _get_cached_scores(self) -> Dict[str, float]:
        return {t: d["score"] for t, d in self._scores.items()}

    # ══════════════════════════════════════════════════════
    #  ПОЛУЧИТЬ НОВОСТИ ПО ТИКЕРУ (для Telegram отчёта)
    # ══════════════════════════════════════════════════════
    def get_ticker_news(self, ticker: str) -> List[dict]:
        if ticker in self._scores:
            return self._scores[ticker].get("news", [])
        return []

    def get_all_scores(self) -> Dict[str, dict]:
        return self._scores
